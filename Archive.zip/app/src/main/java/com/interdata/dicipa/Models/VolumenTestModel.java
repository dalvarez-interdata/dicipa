package com.interdata.dicipa.Models;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;

import com.interdata.dicipa.Adapters.DatabaseAdapter;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Persistence.DataBaseHelper;

import java.util.ArrayList;
import java.util.List;

public class VolumenTestModel {

    public static String DB_TABLE_NAME = DataBaseHelper.DB_TABLE_PREFIX + "volumen_prueba";
    public static String DB_TABLE_NAME_ALIAS = "vp";


    public static String DB_INDEX_ID = "id";
    public static String DB_INDEX_NAME = "nombre";
    public static String DB_INDEX_MIN = "cantidad_min";
    public static String DB_INDEX_MAX = "cantidad_max";
    public static String DB_INDEX_PERIOD = "id_periodo";
    public static String DB_INDEX_DIVISION = "id_division";
    public static String DB_INDEX_CATEGORY = "id_categoria";


    private String id;
    private String name;
    private int min;
    private int max;
    private String id_periodo;
    private String id_division;
    private String id_category;

    //shared preferences var
    private SharedPreferences sharedPref;

    //Database variables
    private SQLiteDatabase model;
    private DatabaseAdapter dbModel;

    public VolumenTestModel(Context context  ) {

        dbModel = new DatabaseAdapter( context );
        dbModel.open();
        model = dbModel.getmDb();
        sharedPref = DicipaApp.getPreferences();
    }

    public VolumenTestModel() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMin() {
        return min;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public int getMax() {
        return max;
    }

    public void setMax(int max) {
        this.max = max;
    }

    public String getId_periodo() {
        return id_periodo;
    }

    public void setId_periodo(String id_periodo) {
        this.id_periodo = id_periodo;
    }

    public String getId_division() {
        return id_division;
    }

    public void setId_division(String id_division) {
        this.id_division = id_division;
    }

    public String getId_category() {
        return id_category;
    }

    public void setId_category(String id_category) {
        this.id_category = id_category;
    }

    public SharedPreferences getSharedPref() {
        return sharedPref;
    }

    public void setSharedPref(SharedPreferences sharedPref) {
        this.sharedPref = sharedPref;
    }

    public SQLiteDatabase getModel() {
        return model;
    }

    public void setModel(SQLiteDatabase model) {
        this.model = model;
    }

    public DatabaseAdapter getDbModel() {
        return dbModel;
    }

    public void setDbModel(DatabaseAdapter dbModel) {
        this.dbModel = dbModel;
    }

    /*
     * Gets the list of volumen test
     *
     * @return List<VolumenTestModel>
     * */
    public List<VolumenTestModel> findAll (Bundle bundle )
    {
        try
        {
            String condition = "WHERE";

            String sql = "SELECT * FROM " +  DB_TABLE_NAME + " AS " + DB_TABLE_NAME_ALIAS;

            if ( bundle.get("category") != null )
                condition += " id_categoria = " +  bundle.getString("category") + " AND";

            if ( bundle.get("division") != null )
                condition += " id_division = " +  bundle.getString("division") + " AND";

            if ( bundle.get("period") != null )
                condition += " id_periodo = " +  bundle.getString("period") + " AND";

            if ( condition.equals("WHERE") )
                condition = "";
            else
                condition = condition.substring(0, condition.length() - 3 );

            sql += " " + condition;

            //sort
            sql = sql + " ORDER BY "+DB_TABLE_NAME_ALIAS+"."+DB_INDEX_ID+" ASC ";

            Cursor mCur = model.rawQuery(sql, null);

            List<VolumenTestModel> tests = new ArrayList<>();

            if (mCur==null)
                return tests;

            for (mCur.moveToFirst(); !mCur.isAfterLast(); mCur.moveToNext()) {
                VolumenTestModel test = getVolumenTestAsObject ( mCur );
                tests.add( test );
            }
            mCur.close();

            return tests;
        }
        catch (SQLException mSQLException)
        {
            Log.e(this.getClass().toString(), "findAll >> "+ mSQLException.toString());
            throw mSQLException;
        }
    }

    /*
     * Gets the user object by cursor position
     *
     * @param Cursor cursor
     * @return UserModel
     *
     * */
    public VolumenTestModel getVolumenTestAsObject (Cursor cursor ) {

        VolumenTestModel test = new VolumenTestModel( );

        //BASICS
        int idIndex = cursor.getColumnIndex( DB_INDEX_ID );
        int nameIndex = cursor.getColumnIndex( DB_INDEX_NAME );
        int maxIndex = cursor.getColumnIndex( DB_INDEX_MAX );
        int minIndex = cursor.getColumnIndex( DB_INDEX_MIN );
        int periodIndex = cursor.getColumnIndex( DB_INDEX_PERIOD );
        int divisionIndex = cursor.getColumnIndex( DB_INDEX_DIVISION );
        int categoryIndex =  cursor.getColumnIndex( DB_INDEX_CATEGORY );

        //id
        long id = cursor.getLong ( idIndex );
        test.setId ( String.valueOf(id) );
        test.setName ( cursor.getString ( nameIndex ) );
        test.setMax ( cursor.getInt( maxIndex )  );
        test.setMin ( cursor.getInt( minIndex ) );
        test.setId_periodo (  cursor.getString ( periodIndex )  );
        test.setId_division (  cursor.getString ( divisionIndex )  );
        test.setId_category (  cursor.getString ( categoryIndex )  );

        return test;


    }

}
