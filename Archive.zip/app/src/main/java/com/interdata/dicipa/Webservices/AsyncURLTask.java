package com.interdata.dicipa.Webservices;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import com.interdata.dicipa.ConfigParams;

import org.apache.http.NameValuePair;

import java.util.ArrayList;


/*
 * Tarea encargada de ejecutar en un hilo secundario los WS, acepta en su constructor 
 * un objeto de tipo MyWebServiceHttpObject y utilica la interfaz MySyncTaskResultListener 
 * para proveer un callback al hilo principal
 * 
 * 
 */
public class AsyncURLTask extends AsyncTask<Void, Void, OperationResult> {

	private String url = null;
	private String method = null;
	private final ArrayList<NameValuePair> my_params;
	private SyncTaskResultListenerInterface my_post_execute_listener = null;
    private int mOperation;
    private Context contexto;

	// url a ejecutar, parametros de la peticion, metodo (GET o POST), callback
	public AsyncURLTask(String url, ArrayList<NameValuePair> nameValuePairs, String method, ProgressDialog dialog,
			SyncTaskResultListenerInterface callback) throws Exception {

		this.url = url;
		this.method = method;
		my_params = nameValuePairs;
		my_post_execute_listener = callback;

		if (my_post_execute_listener == null)
			throw new Exception("Param cannot be null.");
	}

	public AsyncURLTask(WebServiceHttpObject object , Context context) throws Exception {

        this.url = object.getUrl();
		this.method = object.getHttpMethod();
		my_params = object.getMyParams();
		my_post_execute_listener = object.getCallback();
        mOperation = object.getOperation();
        contexto = context;

		if (my_post_execute_listener == null)
			throw new Exception("Param cannot be null.");
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
	}

	@Override
	protected OperationResult doInBackground(Void... params) {
		try {
			OperationResult result = new OperationResult(mOperation);
			ArrayList<Object> tmp = new ArrayList<Object>();
			tmp.add(HttpCallRequest.makeHttpRequest(url, method, my_params));
			result.setData(tmp);
			WebServiceJSONParser parser = new WebServiceJSONParser(contexto);
			switch (mOperation) {

				case ConfigParams.SERVICE_LOGIN:
					return parser.readJsonStreamLogin(result.getStrResult());

					case ConfigParams.SERVICE_USER_PROFILE:
					return parser.readJsonStreamUserProfile(result.getStrResult());


				case ConfigParams.SERVICE_RECOVER_PASSWORD:
					return parser.readJsonStreamConfirmRecoverPassword(result.getStrResult());

					case ConfigParams.DOWNLOAD_IMAGE:
					String[] imgName = url.split("/");
					parser.parseImage(result.getStrResult(), imgName[imgName.length - 1], ConfigParams.APP_USERS_PATH );
					break;
			}
			return result;

		} catch (Exception e) {
			if (!(e.getMessage() == null)) Log.d("ASYNC TASK ERROR: ", e.getMessage());
			else Log.d("ASYNC TASK ERROR: ", "La excepcion desconocida");
			return new OperationResult(e);
		}
	}

	@Override
	protected void onPostExecute(OperationResult result) {

		if (my_post_execute_listener != null) {
			my_post_execute_listener.onSyncTaskEventCompleted(result);
		}

	}
}