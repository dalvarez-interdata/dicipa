package com.interdata.dicipa.Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.interdata.dicipa.Adapters.DatabaseAdapter;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.R;

import java.util.Timer;
import java.util.TimerTask;

public class SplashScreenActivity extends AppCompatActivity {

    private Timer timer;
    private ProgressBar progressBar;
    private int i=0;
    TextView textView;
    private SharedPreferences sharedPref;

    //Database helper
    private static DatabaseAdapter mDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_splash_screen);

        DicipaApp.MyActivity = SplashScreenActivity.this;
        DicipaApp.MyContext = getBaseContext();
        DicipaApp.setPreference();
        sharedPref =  DicipaApp.getPreferences();

        progressBar=(ProgressBar)findViewById(R.id.progressBar);
        progressBar.setScaleY(3f);
        progressBar.setProgress(0);
        textView=(TextView)findViewById(R.id.textView);
        textView.setText("");

        if (sharedPref.getBoolean("firstrun", true)) {

            mDbHelper = new DatabaseAdapter(getApplicationContext());
            mDbHelper.createDatabase();
            mDbHelper.close();
            SharedPreferences.Editor editor = DicipaApp.getPreferences().edit();
            editor.putBoolean("firstrun", true );
        }


        final long period = 20;
        timer=new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                //this repeats every 100 ms
                if (i<100){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            textView.setText(String.valueOf(i)+"%");
                        }
                    });
                    progressBar.setProgress(i);
                    i++;
                }else{
                    //closing the timer
                    timer.cancel();
                    Intent intent =new Intent(SplashScreenActivity.this,SignInActivity.class);
                    startActivity(intent);
                    // close this activity
                    finish();
                }
            }
        }, 0, period);
    }
}
