package com.interdata.dicipa.Tools;

import android.text.Layout;
import android.view.View;

/**
 * Created by Deivis on 12/03/19.
 */

public class DrawerItem {

    private String name;
    private Integer icon;
    private boolean division;

    //private View user_panel;

    public DrawerItem(){}


    public DrawerItem(String name, Integer icon) {
        this.name = name;
        this.icon = icon;
    }

    public DrawerItem(String name, Integer icon, boolean division) {
        this.name = name;
        this.icon = icon;
        this.division = division;
    }

    public boolean isDivision() {
        return division;
    }

    public void setDivision(boolean division) {
        this.division = division;
    }

    public String getName() {
        return name;
    }

    public Integer getIcon() {
        return icon;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIcon(Integer icon) {
        this.icon = icon;
    }
}
