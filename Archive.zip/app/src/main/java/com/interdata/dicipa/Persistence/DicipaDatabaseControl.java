package com.interdata.dicipa.Persistence;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * Created by Deivis Ricardo on 14/03/2019.
 */
public class DicipaDatabaseControl extends SQLiteOpenHelper {

    public static final String NAME = "DICIPA_DB.db";
    public static final int VERSION = 1;

    private static final String CREATE_TABLE_NOTIFICACIONES = "CREATE TABLE notificaciones " +
            "(id_notificacion bigint, tipo int, id_division int, contenido text, leida int default 0, fecha text);";

    private static final String CREATE_TABLE_DIVISIONES = "CREATE TABLE divisiones " +
            "(id_division int, nombre text, id_usuario int, id_division_padre int);";

    private static final String CREATE_TABLE_BITACORA = "CREATE TABLE bitacora " +
            "(fecha text, id_accion int, target_ text, id_usuario int, fecha_sincronizacion text) ;";
    private static final String CREATE_TABLE_ACCIONES_BITACORA = "CREATE TABLE acciones_bitacora " +
            "(id_accion int, descripcion text) ;";

    private static final String CREATE_TABLE_CATEGORIAS = "CREATE TABLE categorias " +
            "(id_categoria int, nombre_categoria text, descripcion text, id_division int);";
    private static final String CREATE_TABLE_RELACION_CATEGORIAS = "CREATE TABLE relacion_categorias(hija int, padre int);";
    private static final String CREATE_TABLE_PRODUCTOS = "CREATE TABLE productos " +
            "(id_producto int, nombre_producto text, " +
            "descripcion_producto text, info_extra text );";
    private static final String CREATE_TABLE_FORMULARIOS = "CREATE TABLE formularios(id_formulario int, formulario text, descripcion text, orden int, id_division int);";
    private static final String CREATE_TABLE_PREGUNTAS = "CREATE TABLE preguntas(id_pregunta text, pregunta text, opciones text, id_tipo_pregunta int);";
    private static final String CREATE_TABLE_RELACION_FORMULARIOS = "CREATE TABLE relacion_formularios(padre int, hijo int);";
    private static final String CREATE_TABLE_RELACION_PREGUNTAS_FORMULARIOS = "CREATE TABLE relacion_preguntas_formularios(id_pregunta text, id_formulario text, orden int, requerido int);";
    private static final String CREATE_TABLE_REL_CAT_PROD = "CREATE TABLE rel_cat_prod " +
            "(id_cat int , " +
            "id_prod int );";
    private static final String CREATE_TABLE_AREAS_AUTORIZADAS = "CREATE TABLE areas_usuarios(id_usuario text, id_area int)";
    private static final String CREATE_TABLE_SOLICITUDES = "CREATE TABLE solicitudes(id_prospectacion text, id_usuario int);";
    private static final String CREATE_TABLE_ESTADOS_PROSPECTACIONES = "CREATE TABLE estados_prospectaciones " +
            "(id_estado_prospectacion text, id_prospectacion text, id_catalogo_status int, fecha_local text, fecha_sincronizacion text, fecha_envio text, observaciones text) ;";
    private static final String CREATE_TABLE_CATALOGO_ESTADOS_PROSPECTACIONES = "CREATE TABLE catalogo_estados_prospectaciones " +
            "(id_catalogo_prospectacion int, descripcion text, cancelacion int) ;";
    private static final String CREATE_TABLE_CONTENIDO_PROSPECTACIONES = "CREATE TABLE contenido_prospectaciones " +
            "(id_estado_prospectacion text, id_pregunta int, contenido text) ;";
    private static final String CREATE_TABLE_PRODUCTOS_SELECCIONADOS = "CREATE TABLE productos_seleccionados " +
            "(id_estado_prospectacion text, id_producto int, cantidad int)";
    private static final String CREATE_TABLE_ARCHIVOS_PRODUCTOS = "CREATE TABLE archivos_productos(id_archivo text, id_producto, nombre_interno text, nombre_real text)";
    private static final String CREATE_TABLE_PREGUNTAS_PRODUCTOS = "CREATE TABLE preguntas_productos(id_pregunta text, id_producto text, requerida int)";

    private Context context;

    public DicipaDatabaseControl (Context context) {
        super(context, NAME, null, VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.v("LOG_TAG", "creando base de datos");

        db.execSQL(CREATE_TABLE_NOTIFICACIONES);
        db.execSQL(CREATE_TABLE_DIVISIONES);
        db.execSQL(CREATE_TABLE_BITACORA);
        db.execSQL(CREATE_TABLE_ACCIONES_BITACORA);
        db.execSQL(CREATE_TABLE_CATEGORIAS);
        db.execSQL(CREATE_TABLE_RELACION_CATEGORIAS);
        db.execSQL(CREATE_TABLE_PRODUCTOS);
        db.execSQL(CREATE_TABLE_REL_CAT_PROD);
        db.execSQL(CREATE_TABLE_FORMULARIOS);
        db.execSQL(CREATE_TABLE_PREGUNTAS);
        db.execSQL(CREATE_TABLE_RELACION_FORMULARIOS);
        db.execSQL(CREATE_TABLE_RELACION_PREGUNTAS_FORMULARIOS);
        db.execSQL(CREATE_TABLE_AREAS_AUTORIZADAS);
        db.execSQL(CREATE_TABLE_SOLICITUDES);
        db.execSQL(CREATE_TABLE_ESTADOS_PROSPECTACIONES);
        db.execSQL(CREATE_TABLE_CONTENIDO_PROSPECTACIONES);
        db.execSQL(CREATE_TABLE_PRODUCTOS_SELECCIONADOS);
        db.execSQL(CREATE_TABLE_ARCHIVOS_PRODUCTOS);
        db.execSQL(CREATE_TABLE_PREGUNTAS_PRODUCTOS);

        db.execSQL("INSERT INTO acciones_bitacora VALUES (1, 'INSERTAR');");
        db.execSQL("INSERT INTO acciones_bitacora VALUES (2, 'ACTUALIZAR');");
        db.execSQL("INSERT INTO acciones_bitacora VALUES (3, 'BORRAR');");
        db.execSQL("INSERT INTO acciones_bitacora VALUES (4, 'INICIAR SESION');");
        db.execSQL("INSERT INTO acciones_bitacora VALUES (5, 'CERRAR SESION');");
        db.execSQL("INSERT INTO acciones_bitacora VALUES (6, 'INSTALAR APLICACION');");
        db.execSQL("INSERT INTO acciones_bitacora VALUES (7, 'DESCARGAR CATALOGO');");
        db.execSQL("INSERT INTO acciones_bitacora VALUES (8, 'CAMBIO DE ACTIVIDAD');");
        db.execSQL("INSERT INTO acciones_bitacora VALUES (9, 'PROSPECTACION GENERADA');");
        db.execSQL("INSERT INTO acciones_bitacora VALUES (10, 'SINCRONIZACION');");
        db.execSQL("INSERT INTO acciones_bitacora VALUES (11, 'INICIAR_APLICACION');" );

        Calendar c = GregorianCalendar.getInstance();
        String fecha = c.get(Calendar.YEAR) + "/" + (c.get(Calendar.MONTH)+1) + "/" + c.get(Calendar.DATE);
        db.execSQL("INSERT INTO bitacora(fecha, id_accion, target_, id_usuario)  VALUES ('" +fecha +"', 6, '', 0);");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        db.execSQL("DROP TABLE IF EXISTS divisiones");
        db.execSQL("DROP TABLE IF EXISTS categorias");
        db.execSQL("DROP TABLE IF EXISTS relacion_categorias");
        db.execSQL("DROP TABLE IF EXISTS productos");
        db.execSQL("DROP TABLE IF EXISTS rel_cat_prod ");
        db.execSQL("DROP TABLE IF EXISTS formularios ");
        db.execSQL("DROP TABLE IF EXISTS preguntas ");
        db.execSQL("DROP TABLE IF EXISTS relacion_formularios ");
        db.execSQL("DROP TABLE IF EXISTS relacion_preguntas_formularios ");
        db.execSQL("DROP TABLE IF EXISTS  areas_usuarios ");
        db.execSQL("DROP TABLE IF EXISTS estados_prospectaciones ");
        db.execSQL("DROP TABLE IF EXISTS catalogo_estados_prospectaciones ");
        db.execSQL("DROP TABLE IF EXISTS archivos_productos ");
        db.execSQL("DROP TABLE IF EXISTS preguntas_productos ");

        db.execSQL(CREATE_TABLE_DIVISIONES);
        db.execSQL(CREATE_TABLE_CATEGORIAS);
        db.execSQL(CREATE_TABLE_RELACION_CATEGORIAS);
        db.execSQL(CREATE_TABLE_PRODUCTOS);
        db.execSQL(CREATE_TABLE_REL_CAT_PROD);
        db.execSQL(CREATE_TABLE_FORMULARIOS);
        db.execSQL(CREATE_TABLE_PREGUNTAS);
        db.execSQL(CREATE_TABLE_RELACION_FORMULARIOS);
        db.execSQL(CREATE_TABLE_RELACION_PREGUNTAS_FORMULARIOS);
        db.execSQL(CREATE_TABLE_AREAS_AUTORIZADAS);
        db.execSQL(CREATE_TABLE_ESTADOS_PROSPECTACIONES);
        db.execSQL(CREATE_TABLE_CATALOGO_ESTADOS_PROSPECTACIONES);
        db.execSQL(CREATE_TABLE_ARCHIVOS_PRODUCTOS);
        db.execSQL(CREATE_TABLE_PREGUNTAS_PRODUCTOS);
    }

    public static void cleanDatabase (Context context) {
        DicipaDatabaseControl dbHelper = new DicipaDatabaseControl (context);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        db.execSQL("DROP TABLE IF EXISTS divisiones");
        db.execSQL("DROP TABLE IF EXISTS categorias");
        db.execSQL("DROP TABLE IF EXISTS relacion_categorias");
        db.execSQL("DROP TABLE IF EXISTS productos");
        db.execSQL("DROP TABLE IF EXISTS rel_cat_prod ");
        db.execSQL("DROP TABLE IF EXISTS formularios ");
        db.execSQL("DROP TABLE IF EXISTS preguntas ");
        db.execSQL("DROP TABLE IF EXISTS relacion_formularios ");
        db.execSQL("DROP TABLE IF EXISTS relacion_preguntas_formularios ");
        db.execSQL("DROP TABLE IF EXISTS  areas_usuarios ");
        db.execSQL("DROP TABLE IF EXISTS solicitudes ");
        db.execSQL("DROP TABLE IF EXISTS estados_prospectaciones ");
        db.execSQL("DROP TABLE IF EXISTS catalogo_estados_prospectaciones ");
        db.execSQL("DROP TABLE IF EXISTS contenido_prospectaciones ");
        db.execSQL("DROP TABLE IF EXISTS productos_seleccionados ");
        db.execSQL("DROP TABLE IF EXISTS archivos_productos ");
        db.execSQL("DROP TABLE IF EXISTS notificaciones");
        db.execSQL("DROP TABLE IF EXISTS usuarios");
        db.execSQL(CREATE_TABLE_NOTIFICACIONES);
        db.execSQL(CREATE_TABLE_DIVISIONES);
        db.execSQL(CREATE_TABLE_CATEGORIAS);
        db.execSQL(CREATE_TABLE_RELACION_CATEGORIAS);
        db.execSQL(CREATE_TABLE_PRODUCTOS);
        db.execSQL(CREATE_TABLE_REL_CAT_PROD);
        db.execSQL(CREATE_TABLE_FORMULARIOS);
        db.execSQL(CREATE_TABLE_PREGUNTAS);
        db.execSQL(CREATE_TABLE_RELACION_FORMULARIOS);
        db.execSQL(CREATE_TABLE_RELACION_PREGUNTAS_FORMULARIOS);
        db.execSQL(CREATE_TABLE_AREAS_AUTORIZADAS);
        db.execSQL(CREATE_TABLE_SOLICITUDES);
        db.execSQL(CREATE_TABLE_ESTADOS_PROSPECTACIONES);
        db.execSQL(CREATE_TABLE_CATALOGO_ESTADOS_PROSPECTACIONES);
        db.execSQL(CREATE_TABLE_CONTENIDO_PROSPECTACIONES);
        db.execSQL(CREATE_TABLE_PRODUCTOS_SELECCIONADOS);
        db.execSQL(CREATE_TABLE_ARCHIVOS_PRODUCTOS);

    }

    public static void executaQuery(Context context1, String query, String... args){
        DicipaDatabaseControl dbHelper = new DicipaDatabaseControl (context1);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.execSQL(query, args);
        db.close();
    }
}
