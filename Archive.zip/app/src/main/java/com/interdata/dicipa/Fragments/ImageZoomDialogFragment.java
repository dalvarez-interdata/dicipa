package com.interdata.dicipa.Fragments;


import android.app.Dialog;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.DialogFragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;


import com.interdata.dicipa.Activities.MainActivity;
import com.interdata.dicipa.Adapters.CustomPagerAdapter;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Models.ProductImage;

import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;

import com.interdata.dicipa.Models.ProductModel;
import com.interdata.dicipa.R;

/**
 * Created by Deivis on 8/12/17.
 */

public class ImageZoomDialogFragment extends DialogFragment {

    private CustomPagerAdapter mCustomPagerAdapter;
    private ViewPager mViewPager;
    private ArrayList<ProductImage> imageSwitcherImages;
    private Dialog dialog;

    private Bundle data;

    public static Handler myHandler ;


    public ImageZoomDialogFragment() {
        // Empty constructor is required for DialogFragment
        // Make sure not to add arguments to the constructor
        // Use `newInstance` instead as shown below
    }

    public static ImageZoomDialogFragment newInstance(String title, Bundle args ) {

        ImageZoomDialogFragment frag = new ImageZoomDialogFragment();

        args.putString("title", title);

        frag.setArguments(args);

        return frag;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        settingVariables ();

        return getActivity().getLayoutInflater().inflate(R.layout.zoom_image_view_layout, container);

    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        getDialog().getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);

        settingInterface ();

    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        dialog = super.onCreateDialog(savedInstanceState);

        // request a window without the title
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);

        data = getArguments();

        return dialog;
    }

    public void onResume() {

        // Store access variables for window and blank point
        Window window = getDialog().getWindow();
        Point size = new Point();
        // Store dimensions of the screen in `size`
        Display display = window.getWindowManager().getDefaultDisplay();
        display.getSize(size);

        // Set the width of the dialog proportional to 99% of the screen width
        window.setLayout((int) (size.x * 1), WindowManager.LayoutParams.WRAP_CONTENT);
        window.setGravity(Gravity.CENTER);
        // Call super onResume after sizing
        super.onResume();

    }

    /*
    * Sets variables*/
    public void settingVariables () {

        ArrayList<ProductImage> images = new ArrayList<>();
        images.add(new ProductImage("id", "DXC 800", "Instrumento automatizado de alto rendimiento para las pruebas de química clínica.", "equipo1.png") );
        images.add(new ProductImage("id", "DXC 800 MAX", "Instrumento automatizado de alto rendimiento para las pruebas de química clínica.", "equipo2.png") );
        images.add(new ProductImage("id", "Biolis 24 | Premium", "Instrumento de mesa, compacto y de fácil manejo, ideal para laboratorios de mediano rendimiento.", "equipo3.png") );
        images.add(new ProductImage("id", "H 3000", "Equipo semi automatizado de mesa, ideal para laboratorios que comienzan o como respaldo de instrumentos automatizados.", "equipo4.png") );

        if ( images.size() == 0 ) {
            ProductImage logo = new ProductImage("id", "DXC 800", "Instrumento automatizado de alto rendimiento para las pruebas de química clínica.", "product_image.png");
            imageSwitcherImages.add ( 0, logo );
        } else {
            imageSwitcherImages = images;
        }

        ((MainActivity)getActivity()).onProgress = false;

    }

    /*
    * Sets the interfaces of the fragment
    * */
    public void settingInterface () {

        getView().findViewById(R.id.iv_dismiss_dialog).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });


        mCustomPagerAdapter = new CustomPagerAdapter(DicipaApp.MyContext, imageSwitcherImages);

        mViewPager = getView().findViewById(R.id.pager);

        mViewPager.setAdapter(mCustomPagerAdapter);

    }

}

