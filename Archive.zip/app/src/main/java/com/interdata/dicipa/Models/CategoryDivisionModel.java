package com.interdata.dicipa.Models;

import java.util.List;

/*
 * CategoryDivisionModel model
 * @auhor Deivis Ricardo
 * @date 15/03/2019*/


public class CategoryDivisionModel {

    private String id;
    private String name;
    private String shortName;
    private String padre;
    private String descripcion;
    private int orden;
    private List<CategoryDivisionModel> subcategories;
    private DivisionModel division;
    private int fromDivision = 0;

    public CategoryDivisionModel() {
    }

    public CategoryDivisionModel(String id, String name, String shortName, String padre, List<CategoryDivisionModel> subcategories, DivisionModel division) {
        this.id = id;
        this.name = name;
        this.shortName = shortName;
        this.padre = padre;
        this.subcategories = subcategories;
        this.division = division;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getPadre() {
        return padre;
    }

    public void setPadre(String padre) {
        this.padre = padre;
    }

    public List<CategoryDivisionModel> getSubcategories() {
        return subcategories;
    }

    public void setSubcategories(List<CategoryDivisionModel> subcategories) {
        this.subcategories = subcategories;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getOrden() {
        return orden;
    }

    public void setOrden(int orden) {
        this.orden = orden;
    }

    public DivisionModel getDivision() {
        return division;
    }

    public void setDivision(DivisionModel division) {
        this.division = division;
    }

    public int getFromDivision() {
        return fromDivision;
    }

    public void setFromDivision(int fromDivision) {
        this.fromDivision = fromDivision;
    }
}
