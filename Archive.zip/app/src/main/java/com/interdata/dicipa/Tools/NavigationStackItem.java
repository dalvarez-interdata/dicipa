package com.interdata.dicipa.Tools;

import android.os.Bundle;

/**
 * Created by Deivis on 1/11/18.
 */

public class NavigationStackItem {

    private int fragment;
    private Bundle data;


    public NavigationStackItem() {
    }

    public NavigationStackItem(int fragment, Bundle data) {
        this.fragment = fragment;
        this.data = data;
    }

    public int getFragment() {
        return fragment;
    }

    public void setFragment(int fragment) {
        this.fragment = fragment;
    }

    public Bundle getData() {
        return data;
    }

    public void setData(Bundle data) {
        this.data = data;
    }


}
