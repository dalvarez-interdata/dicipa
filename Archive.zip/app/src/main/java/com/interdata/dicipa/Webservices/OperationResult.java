package com.interdata.dicipa.Webservices;

import android.accounts.AccountsException;
import android.net.ParseException;
import android.util.Log;

import com.interdata.dicipa.ConfigParams;
import com.interdata.dicipa.R;

import org.apache.http.HttpException;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.HttpHostConnectException;
import org.json.JSONException;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.ArrayList;

import javax.net.ssl.SSLException;

public class OperationResult {

	private static final String TAG = "OperationResult";


	public enum ResultCode {
		ZERO, OK,NO_NEED_TO_UPDATE, UNHANDLED_HTTP_CODE, UNAUTHORIZED, FILE_NOT_FOUND,
		INSTANCE_NOT_CONFIGURED, UNKNOWN_ERROR, WRONG_CONNECTION, 
		TIMEOUT, INCORRECT_ADDRESS, HOST_NOT_AVAILABLE,
		NO_NETWORK_CONNECTION, CANCELLED, 
		INVALID_LOCAL_FILE_NAME, INVALID_OVERWRITE, 
		CONFLICT, LOCAL_STORAGE_FULL, LOCAL_STORAGE_NOT_MOVED, 
		LOCAL_STORAGE_NOT_COPIED, OAUTH2_ERROR_ACCESS_DENIED, 
 IO_EXCEPTION, JSON_EXCEPTION, CLASS_NOT_FOUND_EXCEPTION,SERVICE_ERROR,
 QUOTA_EXCEEDED, ACCOUNT_NOT_FOUND, ACCOUNT_EXCEPTION, ACCOUNT_NOT_NEW, ACCOUNT_NOT_THE_SAME, INVALID_CHARACTER_IN_NAME, UNSOPPORTED_ENCODING_EXCEPTION, CLIENT_PROTOCOL_EXCEPTION, PARSE_EXCEPTION, RESULT_SUCCESS

	}

	private boolean mSuccess = false;
	private int mHttpCode = -1;
	private Exception mException = null;
	private ResultCode mCode = ResultCode.UNKNOWN_ERROR;
    private int mOperation;


	private ArrayList<Object> mData;

	public OperationResult(ResultCode code) {
		mCode = code;
		mSuccess = (code == ResultCode.OK);
		mData = null;
	}

	public OperationResult(boolean success, int httpCode) {
		mSuccess = success;
		mHttpCode = httpCode;

		if (success) {
			mCode = ResultCode.OK;

		} else if (httpCode > 0) {
			switch (httpCode) {
			case HttpStatus.SC_UNAUTHORIZED:
				mCode = ResultCode.UNAUTHORIZED;
				break;
			case HttpStatus.SC_NOT_FOUND:
				mCode = ResultCode.FILE_NOT_FOUND;
				break;
			case HttpStatus.SC_INTERNAL_SERVER_ERROR:
				mCode = ResultCode.INSTANCE_NOT_CONFIGURED;
				break;
			case HttpStatus.SC_CONFLICT:
				mCode = ResultCode.CONFLICT;
				break;
			case HttpStatus.SC_INSUFFICIENT_STORAGE:
				mCode = ResultCode.QUOTA_EXCEEDED;
				break;
			default:
				mCode = ResultCode.UNHANDLED_HTTP_CODE;
				Log.d(TAG, "OperationResult has processed UNHANDLED_HTTP_CODE: " + httpCode);
			}
		}
	}

	public OperationResult(Exception e) {
		mException = e;

		if (e instanceof CanNotContinueExceptions) {
			mCode = ResultCode.CANCELLED;

		} else if (e instanceof SocketException) {
			mCode = ResultCode.WRONG_CONNECTION;

		} else if (e instanceof SocketTimeoutException) {
			mCode = ResultCode.TIMEOUT;

		} else if (e instanceof ConnectTimeoutException) {
			mCode = ResultCode.TIMEOUT;

		} else if (e instanceof MalformedURLException) {
			mCode = ResultCode.INCORRECT_ADDRESS;

		} else if (e instanceof UnknownHostException) {
			mCode = ResultCode.HOST_NOT_AVAILABLE;

		} else if (e instanceof AccountsException) {
			mCode = ResultCode.ACCOUNT_EXCEPTION;

		} else if (e instanceof UnsupportedEncodingException) {
			mCode = ResultCode.UNSOPPORTED_ENCODING_EXCEPTION;

		} else if (e instanceof ClientProtocolException) {
			mCode = ResultCode.CLIENT_PROTOCOL_EXCEPTION;

		} else if (e instanceof ParseException) {
			mCode = ResultCode.PARSE_EXCEPTION;

		} else if (e instanceof HttpHostConnectException) {
			mCode = ResultCode.HOST_NOT_AVAILABLE;

		} else if (e instanceof IOException) {
			mCode = ResultCode.IO_EXCEPTION;

		} else if (e instanceof ClassNotFoundException) {
			mCode = ResultCode.CLASS_NOT_FOUND_EXCEPTION;

		} else {
			mCode = ResultCode.UNKNOWN_ERROR;
		}

		SendHandlerMessage.sendErrorMessage(mCode.ordinal(), this.getLogMessage());

	}

	public OperationResult(int operation) {
		mCode = ResultCode.OK;
		mSuccess = true;
		mData = null;
        mOperation = operation;
	}

	public void setData(ArrayList<Object> files) {
		mData = files;
	}

    public void sendSuccessMessage (){

	    switch (mOperation){
            case ConfigParams.DOWNLOAD_INFO:
                if (mCode == ResultCode.NO_NEED_TO_UPDATE) {
                    SendHandlerMessage.sendSuccesMessage(mOperation, R.string.result_no_need_update_success);
                    return;
                }
                SendHandlerMessage.sendSuccesMessage(mOperation, R.string.result_update_success);
                return;
			case ConfigParams.SERVICE_LOGIN:
				if (mCode == ResultCode.ACCOUNT_NOT_FOUND) {
					SendHandlerMessage.sendSuccesMessage(mOperation, R.string.error_login);
					return;
				}
				SendHandlerMessage.sendSuccesMessage(mOperation, R.string.success_login);
				return;
        }

    }

    public ArrayList<Object> getData() {
		return mData;
	}

	public boolean isSuccess() {
		return mSuccess;
	}

	public boolean isCancelled() {
		return mCode == ResultCode.CANCELLED;
	}

	public int getHttpCode() {
		return mHttpCode;
	}

	public ResultCode getCode() {
		return mCode;
	}

    public void setmCode(ResultCode mCode) {
        this.mCode = mCode;
    }

    public Exception getException() {
		return mException;
	}

	public String getLogMessage() {

		if (mException != null) {
			if (mException instanceof CanNotContinueExceptions) {
				return "Operation cancelled by the caller";

			} else if (mException instanceof SocketException) {
				return "Socket exception";

			} else if (mException instanceof SocketTimeoutException) {
				return "Socket timeout exception";

			} else if (mException instanceof ConnectTimeoutException) {
				return "Connect timeout exception";

			} else if (mException instanceof MalformedURLException) {
				return "Malformed URL exception";

			} else if (mException instanceof UnknownHostException) {
				return "Unknown host exception";

			} else if (mException instanceof SSLException) {
				return "SSL exception";

			} else if (mException instanceof HttpException) {
				return "HTTP violation";

			} else if (mException instanceof IOException) {
				return "Unrecovered transport exception";

			} else if (mException instanceof AccountsException) {
				return "Exception while using account";

			} else if (mException instanceof JSONException) {
				return "JSON exception";

			} else if (mException instanceof ClassNotFoundException) {
				return "El servidor no está implementado";

			}  else {
				return "Unexpected exception";
			}
		}

		if (mCode == ResultCode.INSTANCE_NOT_CONFIGURED) {
			return "The ownCloud server is not configured!";

		} else if (mCode == ResultCode.NO_NETWORK_CONNECTION) {
			return "No network connection";

		} else if (mCode == ResultCode.LOCAL_STORAGE_FULL) {
			return "Local storage full";

		} else if (mCode == ResultCode.LOCAL_STORAGE_NOT_MOVED) {
			return "Error while moving file to final directory";

		} else if (mCode == ResultCode.ACCOUNT_NOT_NEW) {
			return "Account already existing when creating a new one";

		} else if (mCode == ResultCode.ACCOUNT_NOT_THE_SAME) {
			return "Authenticated with a different account than the one updating";
		} else if (mCode == ResultCode.INVALID_CHARACTER_IN_NAME) {
			return "The file name contains an forbidden character";
		}

		return "Operation finished with HTTP status code " + mHttpCode + " (" + (isSuccess() ? "success" : "fail")
				+ ")";
	}

	public boolean isServerFail() {
		return (mHttpCode >= HttpStatus.SC_INTERNAL_SERVER_ERROR);
	}

	public boolean isException() {
		return (mException != null);
	}

	public boolean isTemporalRedirection() {
		return (mHttpCode == 302 || mHttpCode == 307);
	}

	public InputStream getStrResult() {
		InputStream reuslt = null;
		for (Object m : mData) {
			if (m instanceof InputStream)
				reuslt = (InputStream) m;
		}
		return reuslt;
	}





}