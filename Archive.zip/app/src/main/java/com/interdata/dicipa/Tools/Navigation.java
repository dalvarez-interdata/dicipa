package com.interdata.dicipa.Tools;

import java.util.Stack;

/**
 * Created by Deivis on 1/11/18.
 */

public class Navigation {

    private Stack<NavigationStackItem> breadcrump;


    public Navigation() {
        this.breadcrump = new Stack ();
    }

    public Stack<NavigationStackItem> getBreadcrump() {
        return breadcrump;
    }

    public void setBreadcrump(Stack<NavigationStackItem> breadcrump) {
        this.breadcrump = breadcrump;
    }

    public void push ( NavigationStackItem item ) {  this.breadcrump.push(item) ; }

    public NavigationStackItem top ( ) { return this.breadcrump.pop(); }
}
