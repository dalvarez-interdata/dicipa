package com.interdata.dicipa.Models;

import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;

import com.interdata.dicipa.Adapters.DatabaseAdapter;
import com.interdata.dicipa.Persistence.DataBaseHelper;

public class PreguntaModel {

    public static String DB_TABLE_NAME = DataBaseHelper.DB_TABLE_PREFIX + "preguntas";
    public static String DB_TABLE_NAME_ALIAS = "pr";

    private String id;
    private String pregunta;
    private int tipoPregunta;
    private String opciones;
    private int anterior;


    //shared preferences var
    private SharedPreferences sharedPref;

    //Database variables
    private SQLiteDatabase model;
    private DatabaseAdapter dbModel;

    public PreguntaModel() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPregunta() {
        return pregunta;
    }

    public void setPregunta(String pregunta) {
        this.pregunta = pregunta;
    }

    public int getTipoPregunta() {
        return tipoPregunta;
    }

    public void setTipoPregunta(int tipoPregunta) {
        this.tipoPregunta = tipoPregunta;
    }

    public String getOpciones() {
        return opciones;
    }

    public void setOpciones(String opciones) {
        this.opciones = opciones;
    }

    public int getAnterior() {
        return anterior;
    }

    public void setAnterior(int anterior) {
        this.anterior = anterior;
    }
}
