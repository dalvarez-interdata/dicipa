package com.interdata.dicipa;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;


import com.interdata.dicipa.Models.ProductModel;
import com.interdata.dicipa.Tools.Navigation;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


/**
 * Created by Deivis on 04/01/19.
 * Singelton Main Class
 */

public class DicipaApp extends Application implements SharedPreferences.OnSharedPreferenceChangeListener  {

    public static Context MyContext;
    public static Activity MyActivity;
    public static Fragment MyFragment;
    public static Menu MyMenu;
    public static SharedPreferences preferences;
    public static String MyLocale = "es";
    public static boolean asychronous = false;
    public static Bundle data;

    public static List<ProductModel> shopping_cart = new ArrayList<>();

    public static boolean error = false;
    public static String messageError = "";
    private static Navigation navigation;


    @Override
    public void onCreate() {

        super.onCreate();

        DicipaApp.MyContext = getApplicationContext();
        DicipaApp.setMyActivity(null);
        DicipaApp.setMyFragment(null);
        DicipaApp.setMyMenu(null);
        DicipaApp.preferences = null;
        DicipaApp.setLocale();
        DicipaApp.navigation = new Navigation ();
        DicipaApp.data = new Bundle();

    }


    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        preferences = sharedPreferences;
    }

    public static Context getMyContext() {
        return MyContext;
    }

    public static void setMyContext(Context myContext) {
        MyContext = myContext;
    }

    public static Activity getMyActivity() {
        return MyActivity;
    }

    public static void setMyActivity(Activity myActivity) {
        MyActivity = myActivity;
    }

    public static Fragment getMyFragment() {
        return MyFragment;
    }

    public static void setMyFragment(Fragment myFragment) {
        MyFragment = myFragment;
    }

    public static void setMyMenu(Menu MyMenu) { MyMenu = MyMenu; }

    public static void setLocale ( ) {
        Locale myLocale = new Locale ( preferences.getString ( ConfigParams.PREFERENCE_LANGUAGE_KEY, ConfigParams.PREFERENCE_LANGUAGE_ES ) );
        Resources res = DicipaApp.MyContext.getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = myLocale;
        res.updateConfiguration(conf, dm);

    }

    public static void setPreference() {
        preferences = DicipaApp.getMyContext().getSharedPreferences("DicipaPrefs", MODE_PRIVATE);
    }


    public static Bitmap getRoundedCornerBitmap(Drawable drawable, boolean square) {
        int width = 0;
        int height = 0;

        if(drawable == null){
            try {
                InputStream defims = DicipaApp.MyActivity.getAssets().open("no_logo_img.jpeg");
                // load image as Drawable
                drawable = Drawable.createFromStream(defims, null);
            }
            catch(IOException ex) {
                return null;
            }
        }

        Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap() ;

        if(square){
            if(bitmap.getWidth() < bitmap.getHeight()){
                width = bitmap.getWidth();
                height = bitmap.getWidth();
            } else {
                width = bitmap.getHeight();
                height = bitmap.getHeight();
            }
        } else {
            height = bitmap.getHeight();
            width = bitmap.getWidth();
        }

        Bitmap output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        final int color = 0xff424242;
        final Paint paint = new Paint();
        final Rect rect = new Rect(0, 0, width, height);
        final RectF rectF = new RectF(rect);
        final float roundPx = 90;

        paint.setAntiAlias(true);
        canvas.drawARGB(0, 0, 0, 0);
        paint.setColor(color);
        canvas.drawRoundRect(rectF, roundPx, roundPx, paint);

        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, rect, rect, paint);

        return output;
    }


    public static SharedPreferences getPreferences(){ return preferences;}

    public static Handler my_handler = new Handler() {

        // Create handleMessage function

        @Override
        public void handleMessage(Message msg) {

            // busco el mensaje de error
            int error_response = msg.getData().getInt(ConfigParams.TAG_ERROR);

            // si es distinto de cero es que devolvio algo
            if (error_response != 0) {
                String error_message = msg.getData().getString(ConfigParams.MSG_ERROR);

                //TODO Si el error es descargando una img no mostrar TOAST
                //Toast.makeText(my_context, error_message, Toast.LENGTH_SHORT).show();
            }
            int succes_response = msg.getData().getInt(ConfigParams.TAG_SUCCESS);
            if (succes_response != 0) {

                String succes_message = null;

            }
        }
    };

    public static Bitmap getImage(String imageUrl, int desiredWidth, int desiredHeight)
    {
        Bitmap image = null;
        int inSampleSize = 0;


        BitmapFactory.Options options = new BitmapFactory.Options();

        options.inJustDecodeBounds = true;

        options.inSampleSize = inSampleSize;

        try
        {
            URL url = new URL(imageUrl);
            Log.d("message", imageUrl);

            HttpURLConnection connection = (HttpURLConnection)url.openConnection();

            InputStream stream = connection.getInputStream();

            image = BitmapFactory.decodeStream(stream, null, options);

            int imageWidth = options.outWidth;

            int imageHeight = options.outHeight;

            if(imageWidth > desiredWidth || imageHeight > desiredHeight)
            {
                System.out.println("imageWidth:"+imageWidth+", imageHeight:"+imageHeight);

                inSampleSize = inSampleSize + 2;

                getImage(imageUrl, 96, 96);
            }
            else
            {
                options.inJustDecodeBounds = false;

                connection = (HttpURLConnection)url.openConnection();

                stream = connection.getInputStream();

                image = BitmapFactory.decodeStream(stream, null, options);

                return image;
            }
        }

        catch(Exception e)
        {
            Log.e("message", e.toString());
        }

        return image;
    }

    /*
     * shows an error message*/
    public static void showErrorMessage (Context c, String title, String message ) {

        AlertDialog.Builder dialog = new AlertDialog.Builder(c);
        dialog.setIcon(R.drawable.ic_error);
        dialog.setTitle(title);
        dialog.setMessage(message);
        dialog.setPositiveButton(R.string.btn_ok, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss(); } });

        dialog.show();
    }

    /*
    * Shows and alert message*/
    public static void showMessageError (String title, String message, Drawable icon) {

        AlertDialog.Builder dialog = new AlertDialog.Builder(DicipaApp.MyActivity);
        dialog.setIcon(icon);
        dialog.setTitle(title);
        dialog.setMessage(message);
        dialog.setPositiveButton(R.string.btn_ok, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss(); } });
        dialog.show();
    }

    public static Navigation getNavigation() {
        return navigation;
    }

    public static void setNavigation(Navigation navigation) {
        DicipaApp.navigation = navigation;
    }
}
