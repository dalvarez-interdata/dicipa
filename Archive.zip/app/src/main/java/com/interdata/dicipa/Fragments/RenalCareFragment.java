package com.interdata.dicipa.Fragments;

import android.app.Fragment;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.interdata.dicipa.Activities.MainActivity;
import com.interdata.dicipa.Adapters.CategoryDivisionAdapter;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Models.CategoryDivisionModel;
import com.interdata.dicipa.Models.DivisionModel;
import com.interdata.dicipa.R;

import java.util.ArrayList;
import java.util.List;


public class RenalCareFragment extends Fragment {

    private RecyclerView rv_renal_care_category_list;
    private List<CategoryDivisionModel> categories;
    private List<DivisionModel> divisions;
    private DivisionModel parent;
    private CategoryDivisionAdapter categoryDivisionAdapter;
    private LinearLayoutManager linearLayoutManager;

    private Bundle data;
    private SharedPreferences sharedPref;
    public static Handler myHandler ;
    private DivisionModel model;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        data = getArguments();

        setVariables ();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_renal_care, container , false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            DicipaApp.MyActivity.getWindow().setStatusBarColor(getResources().getColor(R.color.renal_statusbar,  DicipaApp.MyActivity.getTheme()));
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            DicipaApp.MyActivity.getWindow().setStatusBarColor(getResources().getColor(R.color.renal_statusbar));
        }

        settingInterface ();
    }

    /*
     * settings variables*/
    /*
     * Sets the variables of the Fragment
     * */
    public void setVariables () {

        DicipaApp.MyFragment = this;
        DicipaApp.MyActivity = getActivity();
        DicipaApp.MyContext = getActivity().getBaseContext();

        getActivity().invalidateOptionsMenu();
        sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);
        model = new DivisionModel( DicipaApp.MyContext );
        categories = new ArrayList();
        divisions = new ArrayList();

        getCategories ();
    }

    /*
     *
     * Sets the visuals interface
     * */
    private void settingInterface () {

        DicipaApp.MyActivity.setTitle( R.string.left_menu_renal_care );
        ((MainActivity)getActivity()).toolbar.setTitle ( R.string.left_menu_renal_care );
        ((MainActivity)getActivity()).toolbar.setBackgroundColor(DicipaApp.MyContext.getResources().getColor(R.color.renal));
        ((MainActivity)getActivity()).toolbar.setTitleTextColor(DicipaApp.MyContext.getResources().getColor(R.color.white));

        linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.scrollToPosition ( data.getInt("scrollToPosition") );
        rv_renal_care_category_list =  getView().findViewById( R.id.rv_renal_care_category_list );
        rv_renal_care_category_list.setLayoutManager(linearLayoutManager);
        registerForContextMenu(rv_renal_care_category_list);


    }

    /*
     * Sets the adapter
     *
     * @param List<AgendaModel> listR
     * @param Bundle bundle
     */
    public void setAdapter (List<CategoryDivisionModel> listR, Bundle bundle) {

        categoryDivisionAdapter = new CategoryDivisionAdapter( listR , (MainActivity) getActivity() , rv_renal_care_category_list , linearLayoutManager, bundle );
        rv_renal_care_category_list.setAdapter(categoryDivisionAdapter);

        if ( listR.size() == 0 ) {
            rv_renal_care_category_list.setVisibility(View.GONE);
            getView().findViewById(R.id.tv_no_result).setVisibility(View.VISIBLE);

        }

        TextView tv = getView().findViewById(R.id.tv_description_text);
        tv.setText(parent.getDescription());

        //((MainActivity)getActivity()).mProgressDialog.dismiss();
        ((MainActivity)getActivity()).onProgress = false;

    }

    /*
     * get categories */
    public void getCategories () {

        ((MainActivity)getActivity()).onProgress = true;

        myHandler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                setAdapter( categories , data );
            }
        };

        new Thread(new Runnable() {
            public void run() {
                getCategoryService ();
            }
        }).start();

    }

    /*
     * get categories from source */
    public void getCategoryService () {

        try {

            parent = model.findDivisionByPk ( data.getInt("divisionId") );
            Bundle params = new Bundle ();
            params.putString("by_parent", parent.getId() );
            Bundle subCategoriesParam = new Bundle();
            subCategoriesParam.putBoolean("parent_null", true );

            divisions = model.findAll( params );
            for (int i = 0; i < divisions.size(); i++) {
                CategoryDivisionModel categoryDivisionModel = new CategoryDivisionModel();
                categoryDivisionModel.setId (divisions.get(i).getId());
                categoryDivisionModel.setName (divisions.get(i).getName());
                categoryDivisionModel.setShortName( divisions.get(i).getShortName() );
                categoryDivisionModel.setDivision(parent);

                List<CategoryDivisionModel> subcategories = model.getAllCategories ( divisions.get(i).getId(), subCategoriesParam );
                categoryDivisionModel.setSubcategories ( subcategories );
                categories.add(categoryDivisionModel);
            }

            //categories.addAll ( model.getAllCategories ( parent.getId() ) );

            Message msg = myHandler.obtainMessage();
            myHandler.sendMessage(msg);

        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
