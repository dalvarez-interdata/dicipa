package com.interdata.dicipa.Persistence;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.interdata.dicipa.ConfigParams;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by Deivis on 04/15/2019.
 */

public class DataBaseHelper extends SQLiteOpenHelper {

    private static String TAG = "DataBaseHelper";
    private static String DB_PATH;
    private static String DB_NAME = "dicipa_app.sqlite";
    public static String DB_TABLE_PREFIX = "dicipa_";
    private SQLiteDatabase mDataBase;
    private final Context mContext;

    /*
    * Default constructor of the class*/
    public DataBaseHelper(Context context)  {
        super(context, DB_NAME, null, Integer.parseInt(ConfigParams.COMPILATION_DATA_VERSION));
        DB_PATH = "/data/data/" + context.getPackageName() + "/databases/";
        this.mContext = context;
    }

    @Override
    public synchronized void close () {
        if(mDataBase != null)
            mDataBase.close();
        super.close();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (newVersion > oldVersion)
        {
            db_delete();
        }

    }

    /**
     * Creates the database in internal storage if it exists but is not current.
     */
    public void createDataBase() throws IOException  {

        boolean mDataBaseExist = checkDataBase();

        if(!mDataBaseExist)  {

            this.getReadableDatabase();

            try {
                copyDataBase();
            }
            catch (IOException mIOException)
            {
                throw new Error("ErrorCopyingDataBase");
            }
        }
    }

    /**
     * Copy the assets database to internal storage.
     */
    private void copyDataBase() throws IOException {

        InputStream mInput = mContext.getAssets().open(DB_NAME);
        String outFileName = DB_PATH + DB_NAME;

        OutputStream mOutput = new FileOutputStream(outFileName);
        byte[] mBuffer = new byte[2048];
        int mLength;
        while ((mLength = mInput.read(mBuffer))>0) {
            mOutput.write(mBuffer, 0, mLength);
        }
        mOutput.flush();
        mOutput.close();
        mInput.close();

    }

    /**
     * Checks the database in internal storage.
     */
    private boolean checkDataBase () {

        SQLiteDatabase mCheckDataBase = null;

        try {

            String myPath = DB_PATH + DB_NAME;
            mCheckDataBase = SQLiteDatabase.openDatabase(myPath, null, SQLiteDatabase.NO_LOCALIZED_COLLATORS);
        }
        catch(SQLiteException mSQLiteException) {
            Log.e(TAG, "DatabaseNotFound " + mSQLiteException.toString());
        }

        if(mCheckDataBase != null) {
            mCheckDataBase.close();
        }

        return mCheckDataBase != null;
    }

    /*
      * Deletes an internal database
     */
    public void db_delete()  {
        File file = new File( DB_PATH + DB_NAME );
        if(file.exists()) {
            file.delete();
            System.out.println("delete database file.");
        }
    }

    /**
     * Opens the database in internal storage.
     */
    public boolean openDataBase() throws SQLException {
        String mPath = DB_PATH + DB_NAME;
        mDataBase = SQLiteDatabase.openDatabase(mPath, null, SQLiteDatabase.NO_LOCALIZED_COLLATORS);
        return mDataBase != null;
    }
}



