package com.interdata.dicipa.Webservices;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;

import com.interdata.dicipa.ConfigParams;
import com.interdata.dicipa.DicipaApp;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.io.ByteArrayOutputStream;
import java.sql.Array;
import java.util.ArrayList;


/**
 * Created by Ppyonki on 09/01/2017.
 * Modified by Deivis 25/12/2018
 */
public class Webservices {

    String host;

    private SharedPreferences sharedPref;

    public Webservices(Context context ){

        sharedPref = context.getSharedPreferences("DicipaPrefs", Context.MODE_PRIVATE);

       if ( ConfigParams.DEBUG_MODE  )
           host = ConfigParams.DEV_WEBSITE_BASE_URL;
       else
           host = ConfigParams.WEBSITE_BASE_URL;

    }


    public WebServiceHttpObject SignIn (String email , String password ){
        try {
            String serviceName = "usuario/do-login";
            ArrayList<NameValuePair> http_params = new ArrayList<NameValuePair>();
            http_params.add(new BasicNameValuePair("username", email));
            http_params.add(new BasicNameValuePair("password", password));
            return new WebServiceHttpObject(host + serviceName, http_params, ConfigParams.HTTP_POST, ConfigParams.SERVICE_LOGIN, null);
        } catch ( Exception e ) {
            Log.d("message", e.getMessage());
        }

        return null;
    }


    public WebServiceHttpObject recoverPassword ( String email  ){
        try {
            String serviceName = "recover-password";
            ArrayList<NameValuePair> http_params = new ArrayList<NameValuePair>();
            http_params.add(new BasicNameValuePair("email", email));
            return new WebServiceHttpObject(host + serviceName, http_params, ConfigParams.HTTP_POST, ConfigParams.SERVICE_RECOVER_PASSWORD, null);
        } catch ( Exception e ) {
            Log.d("message", e.getMessage());
        }

        return null;
    }

    public WebServiceHttpObject resendCode (String email){
        String serviceName = "resend-code";
        ArrayList<NameValuePair> http_params = new ArrayList<NameValuePair>();
        http_params.add(new BasicNameValuePair("email",email));
        return new WebServiceHttpObject( host + serviceName , http_params , ConfigParams.HTTP_POST , ConfigParams.RESEND_CODE , null);
    }


    public WebServiceHttpObject getNotifications ( String userId  ){
        String serviceName = "notifications";
        ArrayList<NameValuePair> http_params = new ArrayList<NameValuePair>();
        http_params.add(new BasicNameValuePair("user", userId ) );
        //http_params.add(new BasicNameValuePair(ConfigParams.HTML_PARAM_AUTH_TOKEN , ConfigParams.AUTH_TOKEN));
        return new WebServiceHttpObject( host + serviceName , http_params , ConfigParams.HTTP_POST , ConfigParams.NOTIFICATIONS_POST , null);
    }

    public WebServiceHttpObject getUserProfile ( String user ){
        String serviceName = "get-user-profile";
        ArrayList<NameValuePair> http_params = new ArrayList<NameValuePair>();
        String id = DicipaApp.getPreferences().getString("session_user", "");
        http_params.add(new BasicNameValuePair("user",id));
        http_params.add(new BasicNameValuePair("idUser",user));
        return new WebServiceHttpObject( host + serviceName , http_params , ConfigParams.HTTP_POST , ConfigParams.SERVICE_USER_PROFILE , null);
    }

}
