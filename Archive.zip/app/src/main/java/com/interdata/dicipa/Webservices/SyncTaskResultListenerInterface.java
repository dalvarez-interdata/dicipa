package com.interdata.dicipa.Webservices;


/*
 * @interface
 * 
 * Interfaz que provee un callback usado para procesar el resultado 
 * de consumir un WS es parte del constructor de la clase AsyncURLTask
 */
public interface SyncTaskResultListenerInterface {

	public void onSyncTaskEventCompleted(OperationResult ws_result);


}
