package com.interdata.dicipa.Models;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;

import com.interdata.dicipa.Adapters.DatabaseAdapter;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Persistence.DataBaseHelper;

import java.util.ArrayList;
import java.util.List;

public class DivisionModel {

    public static String DB_TABLE_NAME = DataBaseHelper.DB_TABLE_PREFIX + "divisiones";
    public static String DB_TABLE_NAME_ALIAS = "dv";

    public static String DB_TABLE_CATEGORY = DataBaseHelper.DB_TABLE_PREFIX + "categorias";
    public static String DB_TABLE_CATEGORY_ALIAS = "ca";


    public static String DB_INDEX_DIVISION_ID = "id_division";
    public static String DB_INDEX_DIVISION_NAME = "nombre";
    public static String DB_INDEX_DIVISION_SHORT_NAME = "abreviatura";
    public static String DB_INDEX_DIVISION_DESC = "descripcion";
    public static String DB_INDEX_DIVISION_PARENT_ID = "id_division_padre";
    public static String DB_INDEX_DIVISION_OPTIONS = "opciones";
    public static String DB_INDEX_DIVISION_ORDER = "orden";

    private String id;
    private String name;
    private String shortName;
    private String description;
    private String parent;
    private String options;
    private int orden;
    private List<CategoryDivisionModel> categories;

    //shared preferences var
    private SharedPreferences sharedPref;

    //Database variables
    private SQLiteDatabase model;
    private DatabaseAdapter dbModel;


    public DivisionModel ( Context context  ) {

        dbModel = new DatabaseAdapter( context );
        dbModel.open();
        model = dbModel.getmDb();
        sharedPref = DicipaApp.getPreferences();
    }

    public DivisionModel ( ) {

    }


    public DivisionModel(String id, String name, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public String getParent() {
        return parent;
    }

    public void setParent(String parent) {
        this.parent = parent;
    }

    public String getOptions() {
        return options;
    }

    public void setOptions(String options) {
        this.options = options;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<CategoryDivisionModel> getCategories() {
        return categories;
    }

    public void setCategories(List<CategoryDivisionModel> categories) {
        this.categories = categories;
    }

    public static String getShortCode (String name ) {

        String[] parts = name.split(" ");
        if ( parts.length == 1 )
            return ( String.valueOf ( name.charAt(0) )  +  String.valueOf ( name.charAt (1 ) ) ).toUpperCase();
        else {
            if (  (parts[1].length() == 1 && parts.length == 2 ) || parts[1].length() > 3 )
                return ( String.valueOf ( parts[0].charAt(0) ) +  String.valueOf ( parts[1].charAt(0) ) ).toUpperCase();
            else
                return ( String.valueOf ( parts[0].charAt(0) ) +  String.valueOf ( parts[2].charAt(0) ) ).toUpperCase();
        }
    }

    /*
     * Get a division by id
     *
     * @param long key
     * @return DivisionModel */

    public DivisionModel findDivisionByPk ( int pk ) {
        try  {

            String condition = "";
            String join = "";

            String sql = "SELECT * FROM " + DB_TABLE_NAME + " AS " + DB_TABLE_NAME_ALIAS;

            condition = " WHERE " + DB_TABLE_NAME_ALIAS + "." + DB_INDEX_DIVISION_ID + "=" + String.valueOf(pk);

            sql+=condition;

            Cursor mCur = model.rawQuery(sql, null);

            if (mCur == null || mCur.getCount() == 0 )
                return null;

            mCur.moveToFirst();

            DivisionModel division = getDivisionAsObject ( mCur );

            mCur.close();

            return division;

        }
        catch (SQLException mSQLException)
        {
            Log.e(this.getClass().toString(), "findByPk >> "+ mSQLException.toString());
            throw mSQLException;
        }
    }

    /*
     * Gets the list of divisions
     *
     * @return List<DivisionModel>
     * */
    public List<DivisionModel> findAll (Bundle bundle )
    {
        try
        {
            String condition = "";

            String sql = "SELECT * FROM " +  DB_TABLE_NAME + " AS " + DB_TABLE_NAME_ALIAS;

            if ( bundle.get("parent_null") != null ) {
                condition = " WHERE " + DB_TABLE_NAME_ALIAS + "." + DB_INDEX_DIVISION_PARENT_ID + " IS NULL";
            }

            if ( bundle.get("by_parent") != null ) {
                condition = " WHERE " + DB_TABLE_NAME_ALIAS + "." + DB_INDEX_DIVISION_PARENT_ID + " = " +  bundle.getString("by_parent");
            }

            sql += condition;

            //sort
            sql = sql + " ORDER BY "+DB_TABLE_NAME_ALIAS+"."+DB_INDEX_DIVISION_ORDER+" ASC ";

            Cursor mCur = model.rawQuery(sql, null);

            List<DivisionModel> divisionList = new ArrayList<>();

            if (mCur==null)
                return divisionList;

            for (mCur.moveToFirst(); !mCur.isAfterLast(); mCur.moveToNext()) {
                DivisionModel division = getDivisionAsObject ( mCur );
                divisionList.add( division );
            }
            mCur.close();

            //find all categories for each division

            return divisionList;
        }
        catch (SQLException mSQLException)
        {
            Log.e(this.getClass().toString(), "findAll >> "+ mSQLException.toString());
            throw mSQLException;
        }
    }

    /*
     * Gets the list of divisions
     *
     * @return List<DivisionModel>
     * */
    public List<CategoryDivisionModel> getAllCategories ( String id )
    {
        try
        {
            String condition = "";

            String sql = "SELECT * FROM " + DB_TABLE_CATEGORY + " AS " + DB_TABLE_CATEGORY_ALIAS;
            condition = " WHERE eliminada = 0 AND " + DB_TABLE_CATEGORY_ALIAS + "." + DB_INDEX_DIVISION_ID + " = " + id;
            sql += condition;

            //sort
            sql = sql + " ORDER BY "+DB_TABLE_CATEGORY_ALIAS+".orden ASC ";


            Cursor mCur = model.rawQuery(sql, null);

            List<CategoryDivisionModel> categories = new ArrayList<>();

            if (mCur==null)
                return categories;

            for (mCur.moveToFirst(); !mCur.isAfterLast(); mCur.moveToNext()) {
                CategoryDivisionModel category = geCategoryAsObject ( mCur );
                DivisionModel division = new DivisionModel();
                division.setId(id);
                category.setDivision(division);
                category.setFromDivision(0);

                categories.add( category );
            }
            mCur.close();

            return categories;
        }
        catch (SQLException mSQLException)
        {
            Log.e("message", "findAll >> "+ mSQLException.toString());
            throw mSQLException;
        }
    }


    /*
     * Gets the list of categories
     *
     * @return List<CategoryDivisionModel>
     * */
    public List<CategoryDivisionModel> getAllCategories ( String id, Bundle params )
    {
        try
        {
            String condition = "";

            String sql = "SELECT * FROM " + DB_TABLE_CATEGORY + " AS " + DB_TABLE_CATEGORY_ALIAS;
            condition = " WHERE eliminada = 0 AND " + DB_TABLE_CATEGORY_ALIAS + "." + DB_INDEX_DIVISION_ID + " = " + id;

            if ( params.get("parent_null") != null ) {
                condition += " AND padre IS NULL";
            }
            if ( params.get("parent") != null ) {
                condition += " AND padre =" + params.getString("parent") ;
            }

            sql += condition;

            //sort
            sql = sql + " ORDER BY "+DB_TABLE_CATEGORY_ALIAS+".orden ASC ";


            Cursor mCur = model.rawQuery(sql, null);

            List<CategoryDivisionModel> categories = new ArrayList<>();

            if (mCur==null)
                return categories;

            for (mCur.moveToFirst(); !mCur.isAfterLast(); mCur.moveToNext()) {
                CategoryDivisionModel category = geCategoryAsObject ( mCur );
                DivisionModel division = new DivisionModel();
                division.setId(id);
                category.setDivision(division);
                category.setFromDivision(0);

                categories.add( category );
            }
            mCur.close();

            return categories;
        }
        catch (SQLException mSQLException)
        {
            Log.e("message", "findAll >> "+ mSQLException.toString());
            throw mSQLException;
        }
    }


    /*
     * Gets the list of categories by parent
     *
     * @return List<CategoryDivisionModel>
     * */
    public List<CategoryDivisionModel> getAllCategoriesByParams (  Bundle params )
    {
        try
        {
            String condition = "";

            String sql = "SELECT * FROM " + DB_TABLE_CATEGORY + " AS " + DB_TABLE_CATEGORY_ALIAS;
            condition = " WHERE eliminada = 0 ";

            if ( params.get("parent") != null ) {
                condition += " AND padre =" + params.getString("parent") ;
            }

            sql += condition;

            //sort
            sql = sql + " ORDER BY "+DB_TABLE_CATEGORY_ALIAS+".orden ASC ";


            Cursor mCur = model.rawQuery(sql, null);

            List<CategoryDivisionModel> categories = new ArrayList<>();

            if (mCur==null)
                return categories;

            for (mCur.moveToFirst(); !mCur.isAfterLast(); mCur.moveToNext()) {
                CategoryDivisionModel category = geCategoryAsObject ( mCur );
                DivisionModel division = new DivisionModel();
                division.setId(id);
                category.setDivision(division);
                category.setFromDivision(0);

                categories.add( category );
            }
            mCur.close();

            return categories;
        }
        catch (SQLException mSQLException)
        {
            Log.e("message", "findAll >> "+ mSQLException.toString());
            throw mSQLException;
        }
    }



    /*
     * Gets the user object by cursor position
     *
     * @param Cursor cursor
     * @return UserModel
     *
     * */
    public DivisionModel getDivisionAsObject ( Cursor cursor ) {

        DivisionModel division = new DivisionModel ( );

        //BASICS
        int idDivisionIndex = cursor.getColumnIndex( DB_INDEX_DIVISION_ID );
        int divisionNameIndex = cursor.getColumnIndex( DB_INDEX_DIVISION_NAME );
        int divisionAbbrIndex = cursor.getColumnIndex( DB_INDEX_DIVISION_SHORT_NAME );

        int divisionDescIndex = cursor.getColumnIndex( DB_INDEX_DIVISION_DESC );
        int divisionParentIndex = cursor.getColumnIndex( DB_INDEX_DIVISION_PARENT_ID );
        int divisionOptionIndex = cursor.getColumnIndex( DB_INDEX_DIVISION_OPTIONS );

        //id
        long id = cursor.getLong ( idDivisionIndex );
        division.setId ( String.valueOf(id) );
        division.setName ( cursor.getString ( divisionNameIndex ) );
        division.setShortName ( cursor.getString ( divisionAbbrIndex )  );
        division.setDescription ( cursor.getString ( divisionDescIndex ) );
        division.setOptions ( cursor.getString ( divisionOptionIndex ) );
        division.setParent ( String.valueOf ( divisionParentIndex ) );

        return division;

    }

    /*
     * Gets the user object by cursor position
     *
     * @param Cursor cursor
     * @return CategoryDivisionModel
     *
     * */
    public CategoryDivisionModel geCategoryAsObject ( Cursor cursor ) {

        CategoryDivisionModel category = new CategoryDivisionModel ( );

        //BASICS
        int idCategoryIndex = cursor.getColumnIndex( "id_categoria" );
        int categoryNameIndex = cursor.getColumnIndex( "nombre" );
        int categoryAbbrIndex = cursor.getColumnIndex( "abreviatura" );
        int categoryDescripcionIndex = cursor.getColumnIndex( "descripcion" );
        int categoryOrdenIndex = cursor.getColumnIndex( "orden" );

        //id
        long id = cursor.getLong ( idCategoryIndex );
        category.setId ( String.valueOf(id) );
        category.setName ( cursor.getString ( categoryNameIndex ) );
        category.setShortName ( cursor.getString ( categoryAbbrIndex )  );
        category.setDescripcion ( cursor.getString ( categoryDescripcionIndex ) );
        category.setOrden ( cursor.getInt ( categoryOrdenIndex ) );

        return category;

    }
}
