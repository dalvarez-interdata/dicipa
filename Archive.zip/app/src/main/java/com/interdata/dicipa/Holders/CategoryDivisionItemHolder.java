package com.interdata.dicipa.Holders;

import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.text.Spanned;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.interdata.dicipa.R;

public class CategoryDivisionItemHolder extends RecyclerView.ViewHolder {

    private String id;
    private TextView name;
    private TextView shortName;


    public CategoryDivisionItemHolder(View itemView) {
        super(itemView);
        this.name = itemView.findViewById(R.id.tv_test_name);
        this.shortName = (TextView) itemView.findViewById (R.id.tv_test_short_name );
    }

    public String getId() {
        return id;
    }


    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name.setText (name);
    }

    public TextView getName() {
        return name;
    }

    public void setName(TextView name) {
        this.name = name;
    }

    public TextView getShortName() {
        return shortName;
    }

    public void setShortName(TextView shortName) {
        this.shortName = shortName;
    }

    public void setShortName(String shortName) {
        this.shortName.setText(shortName);
    }
}
