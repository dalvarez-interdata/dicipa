package com.interdata.dicipa.Webservices;

import org.apache.http.NameValuePair;

import java.util.ArrayList;

/*
 * Objeto utilizado por la interfaz WebServiceInterface y en el constructor
 * de la clase AsyncURLTask como utilidad para simplificar los datos del WS
 * 
 */
public class WebServiceHttpObject {

	String url;
	ArrayList<NameValuePair> my_params;
	String method;
    int mOperation;
	SyncTaskResultListenerInterface callback;

	public WebServiceHttpObject(String url, ArrayList<NameValuePair> nameValuePairs, String method, int operation,
			SyncTaskResultListenerInterface callback ) {

		this.url = url;
		this.method = method;
		this.my_params = nameValuePairs;
        this.mOperation = operation;
		this.callback = callback;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public ArrayList<NameValuePair> getMyParams() {
		return my_params;
	}

	public void setMyParams(ArrayList<NameValuePair> my_params) {
		this.my_params = my_params;
	}

	public String getHttpMethod() {
		return method;
	}

	public void setHttpMethod(String method) {
		this.method = method;
	}

	public SyncTaskResultListenerInterface getCallback() {
		return callback;
	}

	public void setCallback(SyncTaskResultListenerInterface callback) {
		this.callback = callback;
	}

    public int getOperation() { return mOperation;}

    public void setOperation(int mOperation) { this.mOperation = mOperation;}
}
