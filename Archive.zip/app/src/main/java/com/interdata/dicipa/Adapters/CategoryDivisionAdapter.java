package com.interdata.dicipa.Adapters;

import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.interdata.dicipa.Activities.MainActivity;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Fragments.BloodBankFragment;
import com.interdata.dicipa.Fragments.ClinicLaboratoryFragment;
import com.interdata.dicipa.Fragments.CotizationDialogFragment;
import com.interdata.dicipa.Fragments.ImagenologyFragment;
import com.interdata.dicipa.Fragments.RenalCareFragment;
import com.interdata.dicipa.Fragments.SubcategoryDialogFragment;
import com.interdata.dicipa.Fragments.VolumenTestDialogFragment;
import com.interdata.dicipa.Holders.CategoryDivisionItemHolder;
import com.interdata.dicipa.Models.CategoryDivisionModel;

import java.util.List;

import com.interdata.dicipa.Models.ProductModel;
import com.interdata.dicipa.R;
import com.interdata.dicipa.ConfigParams;

/**
 * Created by Deivis on 03/12/19.
 */

public class CategoryDivisionAdapter extends RecyclerView.Adapter<CategoryDivisionItemHolder>  {

    private String id;
    private List<CategoryDivisionModel> list;
    private MainActivity listener;
    private RecyclerView listView;
    private RecyclerView.LayoutManager llManager;
    private Bundle params;

    public static VolumenTestDialogFragment volumenTestDialogFragment;
    public static SubcategoryDialogFragment subcategoryDialogFragment;

    public CategoryDivisionAdapter(List<CategoryDivisionModel> list , MainActivity listener , RecyclerView listView , RecyclerView.LayoutManager linearLayoutManager, Bundle params) {
        this.id = "";
        this.list = list;
        this.listener = listener;
        this.listView = listView;
        this.llManager = linearLayoutManager;
        this.params = params;
    }

    @Override
    public long getItemId(int position) {
        return Long.parseLong(list.get(position).getId());
    }

    @Override
    public int getItemCount() {
        if(list == null){
            return 0;
        }
        return list.size();
    }

    @Override
    public CategoryDivisionItemHolder onCreateViewHolder(final ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from ( parent.getContext() ).inflate(R.layout.holder_item_tests, parent, false);

        return new CategoryDivisionItemHolder(itemView);
    };

    @Override
    public void onBindViewHolder(final CategoryDivisionItemHolder holder, final int position) {

        final CategoryDivisionModel item = list.get (position);
        holder.setId ( item.getId() );
        holder.setName ( item.getName() );
        holder.setShortName( item.getShortName() );

        if (DicipaApp.MyFragment instanceof ClinicLaboratoryFragment)
            holder.itemView.findViewById(R.id.ly_shape_circle).setBackgroundDrawable(DicipaApp.MyContext.getResources().getDrawable(R.drawable.shape_circle_clinic_laboratory));
        else if (DicipaApp.MyFragment instanceof RenalCareFragment)
            holder.itemView.findViewById(R.id.ly_shape_circle).setBackgroundDrawable(DicipaApp.MyContext.getResources().getDrawable(R.drawable.shape_circle_renal));
        else if (DicipaApp.MyFragment instanceof BloodBankFragment)
            holder.itemView.findViewById(R.id.ly_shape_circle).setBackgroundDrawable(DicipaApp.MyContext.getResources().getDrawable(R.drawable.shape_circle_blood_bank));
        else if (DicipaApp.MyFragment instanceof ImagenologyFragment)
            holder.itemView.findViewById(R.id.ly_shape_circle).setBackgroundDrawable(DicipaApp.MyContext.getResources().getDrawable(R.drawable.shape_circle_imagenology));


        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                return false;
            }
        });

        if ( item.getSubcategories() != null && item.getSubcategories().size() > 0 ) {

            LinearLayout ly_subcategories = holder.itemView.findViewById(R.id.ly_subcategories);
            ly_subcategories.removeAllViews();

            for (int i = 0; i < item.getSubcategories().size(); i++ ) {

                final CategoryDivisionModel model =  item.getSubcategories().get(i);

                LinearLayout ly_wrapper = new LinearLayout( DicipaApp.MyContext);
                ly_wrapper.setOrientation(LinearLayout.HORIZONTAL);

                View divider = new View(DicipaApp.MyContext);
                LinearLayout.LayoutParams layoutParamsView = new LinearLayout.LayoutParams(96, 96);
                layoutParamsView.setMargins(135,20,10,10);
                divider.setLayoutParams(layoutParamsView);

                if ( DicipaApp.MyFragment instanceof ImagenologyFragment )
                    divider.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.shape_circle_imagenology));
                else if ( DicipaApp.MyFragment instanceof RenalCareFragment )
                    divider.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.shape_circle_renal));
                else if ( DicipaApp.MyFragment instanceof BloodBankFragment )
                    divider.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.shape_circle_blood_bank));

                ly_wrapper.addView (divider);

                TextView sub = new TextView(DicipaApp.MyContext);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                layoutParams.setMargins(20,30,10,10);
                sub.setLayoutParams ( layoutParams );
                sub.setText(item.getSubcategories().get(i).getName());
                sub.setTextColor(DicipaApp.MyContext.getResources().getColor(R.color.colorAccent));
                sub.setTextSize(15);
                ly_wrapper.addView (sub);

                View v = new View(DicipaApp.MyContext);
                LinearLayout.LayoutParams layoutParamsView2 = new LinearLayout.LayoutParams(6, 70);
                layoutParamsView2.setMargins(180,10,10,0);
                v.setLayoutParams(layoutParamsView2);
                v.setBackgroundColor(DicipaApp.MyContext.getResources().getColor(R.color.elementsDivider));
                ly_subcategories.addView(v);

                //tap action
                ly_wrapper.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Log.d("message", "sii!!");
                        Bundle data = new Bundle();
                        data.putString("division", item.getDivision().getId());
                        data.putString("category", item.getId());
                        data.putString("subcategory", model.getId());
                        data.putString("divisionName", item.getDivision().getName());
                        data.putString("categoryName", item.getName());
                        data.putString("subcategoryName", model.getName());
                        showSubCategoryTree ( data );

                    }
                });

                ly_subcategories.addView(ly_wrapper);
            }
        }

        holder.itemView.setOnClickListener( new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                /*if ( item.getSubcategories() == null  ) {

                    Bundle data = new Bundle();
                    data.putInt("fragment", ConfigParams.CATEGORY_DIVISION_DETAIL_FRAGMENT);
                    data.putString("id", item.getId());
                    data.putString("categoryName", item.getName());
                    data.putString("divisionId", item.getDivision().getId());
                    data.putString("divisionName", item.getDivision().getName());
                    data.putInt("scrollToPosition", llManager.getPosition(view) );
                    ((MainActivity) DicipaApp.MyActivity ).settingFragment(true, data);

                } else {

                }*/

                if ( item.getSubcategories() != null && item.getSubcategories().size() > 0 ) {

                    LinearLayout ly_subcategories = holder.itemView.findViewById(R.id.ly_subcategories);

                    if (  ly_subcategories.getVisibility() == View.VISIBLE )
                        ly_subcategories.setVisibility(View.GONE);
                    else
                        ly_subcategories.setVisibility(View.VISIBLE);

                } else {

                    Bundle data = new Bundle();
                    data.putInt("fragment", ConfigParams.CATEGORY_DIVISION_DETAIL_FRAGMENT);
                    if ( item.getFromDivision() == 0 )
                        data.putString("category", item.getId());
                    else
                        data.putString("division", item.getId());

                    data.putString("categoryName", item.getName());
                    data.putString("divisionId", item.getDivision().getId());
                    data.putString("divisionName", item.getDivision().getName());
                    data.putInt("fromDivision", item.getFromDivision());
                    data.putInt("scrollToPosition", llManager.getPosition(view) );

                    showVolumentTest ( data );

                }



            }
        });
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    /*
     * Shows volumen test design */
    /*
     * */
    public void showVolumentTest ( Bundle data ) {

        FragmentManager fm =  ((MainActivity)DicipaApp.MyActivity).getSupportFragmentManager();

        volumenTestDialogFragment = volumenTestDialogFragment.newInstance(DicipaApp.MyContext.getResources().getString(R.string.test_month), data );

        volumenTestDialogFragment.show(fm, "fragment_volument_test_dialog");

    }

    /*
     * Shows subcategory tree */
    /*
     * */
    public void showSubCategoryTree ( Bundle data ) {

        FragmentManager fm =  ((MainActivity)DicipaApp.MyActivity).getSupportFragmentManager();

        subcategoryDialogFragment = subcategoryDialogFragment.newInstance("", data );

        subcategoryDialogFragment.show(fm, "fragment_subcategory_tree_dialog");

    }

}
