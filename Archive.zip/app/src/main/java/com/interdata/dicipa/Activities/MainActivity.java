package com.interdata.dicipa.Activities;

import android.Manifest;
import android.app.Activity;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.NavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Fragments.BloodBankFragment;
import com.interdata.dicipa.Fragments.CategoryDivisionDetailFragment;
import com.interdata.dicipa.Fragments.ClinicLaboratoryFragment;
import com.interdata.dicipa.Fragments.ImageZoomDialogFragment;
import com.interdata.dicipa.Fragments.ImagenologyFragment;
import com.interdata.dicipa.Fragments.MainFragment;
import com.interdata.dicipa.Fragments.RenalCareFragment;
import com.interdata.dicipa.Models.CategoryDivisionModel;
import com.interdata.dicipa.Models.UserModel;
import com.interdata.dicipa.R;
import com.interdata.dicipa.ConfigParams;
import com.interdata.dicipa.Tools.DrawerItem;
import com.interdata.dicipa.Tools.Navigation;
import com.interdata.dicipa.Tools.NavigationStackItem;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    public boolean onProgress = false;
    private SharedPreferences sharedPref;
    public ProgressDialog mProgressDialog;
    public Bundle instaceStateBundle;
    private Intent sharingIntent;
    public BottomNavigationView bottomNavigationView;

    private DrawerLayout mDrawerLayout;
    public ActionBarDrawerToggle toggle;
    private ListView mDrawerList;
    public ProgressBar progressBar;

    public Toolbar toolbar;


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    return true;
                case R.id.navigation_dashboard:
                    return true;
                case R.id.navigation_notifications:
                    return true;
            }
            return false;
        }
    };

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        initToolBar ();

        setPermissions ();

        setVariables ();

        settingDrawer ();

        Bundle bundle = new Bundle();
        bundle.putInt("fragment", ConfigParams.MAIN_FRAGMENT);
        settingFragment(true, bundle );
    }

    // Menu icons are inflated just as they were with actionbar
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        DicipaApp.MyActivity = this;

        getMenuInflater().inflate(R.menu.main, menu);

        menu.findItem ( R.id.action_filter ).setVisible(false);

        /*Sign out item*/
        menu.findItem ( R.id.action_logout ).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                logOut ();
                return false;
            }
        });

        if ( DicipaApp.MyFragment instanceof CategoryDivisionDetailFragment ) {
            menu.findItem ( R.id.action_filter ).setVisible(true);
        }

        return true;
    }

    /*
     * Action when the user press back button on Android
     * */
    @Override
    public void onBackPressed () {

        if ( DicipaApp.getNavigation().getBreadcrump().size() == 0 ) {
                super.onBackPressed();
        }
        else {
            DicipaApp.getNavigation().top();
            NavigationStackItem nav = DicipaApp.getNavigation().top();
            Bundle data = nav.getData();
            data.putInt("fragment", nav.getFragment());
            if ( instaceStateBundle.get("scrollToPosition") != null )
                data.putInt("scrollToPosition", instaceStateBundle.getInt("scrollToPosition"));
            settingFragment(true, data );
        }
    }

    /*
     * settings variables*/
    /*
     * Sets the variables of the Activity
     * */
    public void setVariables () {

        DicipaApp.MyActivity = MainActivity.this;
        DicipaApp.MyContext = getBaseContext();

        DicipaApp.setPreference();
        sharedPref = DicipaApp.getPreferences();

        DicipaApp.setNavigation(new Navigation());

        instaceStateBundle = new Bundle();

        // Initialize the progress dialog
        mProgressDialog = new ProgressDialog(MainActivity.this);
        mProgressDialog.setIndeterminate(true);
        // Progress dialog horizontal style
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        // Progress dialog message
        mProgressDialog.setMessage( getBaseContext().getResources().getString(R.string.loading_content_text) );

    }


    /*
     * Initializes the fragments
     * */
    public boolean settingFragment ( boolean replace, Bundle bundle) {

        if ( onProgress )
            return false;

        if ( bundle.get("scrollToPosition") != null )
            instaceStateBundle.putInt("scrollToPosition", bundle.getInt("scrollToPosition"));

        onProgress = true;
        Fragment newFragment = new Fragment();

        NavigationStackItem nav = new NavigationStackItem();

        switch ( bundle.getInt("fragment") ) {

            case ConfigParams.MAIN_FRAGMENT:
                newFragment = new MainFragment();
                nav.setFragment ( ConfigParams.MAIN_FRAGMENT );
                break;

            case ConfigParams.CLINIC_LABORATORY_FRAGMENT:
                newFragment = new ClinicLaboratoryFragment();
                nav.setFragment ( ConfigParams.CLINIC_LABORATORY_FRAGMENT );
                break;

            case ConfigParams.BLOOD_BANK_FRAGMENT:
                newFragment = new BloodBankFragment();
                nav.setFragment ( ConfigParams.BLOOD_BANK_FRAGMENT );
                break;

            case ConfigParams.RENAL_CARE_FRAGMENT:
                newFragment = new RenalCareFragment();
                nav.setFragment ( ConfigParams.RENAL_CARE_FRAGMENT );
                break;

            case ConfigParams.IMAGENOLOGY_FRAGMENT:
                newFragment = new ImagenologyFragment();
                nav.setFragment ( ConfigParams.IMAGENOLOGY_FRAGMENT );
                break;

            case ConfigParams.CATEGORY_DIVISION_DETAIL_FRAGMENT:
                newFragment = new CategoryDivisionDetailFragment();
                nav.setFragment ( ConfigParams.CATEGORY_DIVISION_DETAIL_FRAGMENT );
                break;

        }

        DicipaApp.getNavigation().push ( nav );
        newFragment.setArguments(bundle);
        nav.setData ( bundle );
        getFragmentManager().beginTransaction().replace(R.id.content_frame , newFragment).commit();

        return true;
    }

    /*
     * Sets permissions*/
    public void setPermissions () {

        //WriteExternal
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            } else {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        ConfigParams.MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
            }
        }

        //internet
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.INTERNET)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.INTERNET)) {

            } else {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.INTERNET},
                        ConfigParams.MY_PERMISSIONS_REQUEST_INTERNET);
            }
        }

        //internet
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_WIFI_STATE)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_WIFI_STATE)) {

            } else {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_WIFI_STATE},
                        ConfigParams.MY_ACCESS_WIFI_STATE);

            }
        }

        //network
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_NETWORK_STATE)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_NETWORK_STATE)) {

            } else {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_NETWORK_STATE},
                        ConfigParams.MY_ACCESS_NETWORK_STATE);

            }
        }

        //location
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_COARSE_LOCATION)) {

            } else {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                        ConfigParams.MY_ACCESS_COARSE_LOCATION);
            }
        }

        //location
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

            } else {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        ConfigParams.MY_ACCESS_FINE_LOCATION);
            }
        }

        //location
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_LOCATION_EXTRA_COMMANDS)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_LOCATION_EXTRA_COMMANDS)) {

            } else {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_LOCATION_EXTRA_COMMANDS},
                        ConfigParams.MY_ACCESS_LOCATION_EXTRA_COMMANDS);
            }
        }
    }

    /*
     * Initializes the ToolBar
     * */
    public void initToolBar ( ) {

        toolbar = findViewById(R.id.app_toolbar);
        toolbar.setBackgroundDrawable(getResources().getDrawable(R.drawable.actionbar_bg));
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayShowTitleEnabled(false);
        toolbar.setNavigationOnClickListener (
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mDrawerLayout.openDrawer ( GravityCompat.START);
                    }
                }
        );
    }

    /**
     * Initializes the Drawer*/
    private void settingDrawer () {

        String[] mDrawerLayoutItemsNames = getResources().getStringArray(R.array.drawer_list_names);
        mDrawerLayout = findViewById(R.id.drawer_layout_principal);
        toolbar = findViewById( R.id.app_toolbar );

        toggle = new ActionBarDrawerToggle(this , mDrawerLayout , toolbar , R.string.app_name , R.string.app_name) {
            @Override
            public void onDrawerClosed(View drawerView) {
                super.onDrawerClosed(drawerView);
            }
        };

        mDrawerLayout.setDrawerListener(toggle);
        mDrawerList = findViewById(R.id.left_drawer);
        final ArrayList<DrawerItem> drawerItems = new ArrayList<>();

        drawerItems.add(new DrawerItem());
        for (int i = 1; i < mDrawerLayoutItemsNames.length   ; i++) {
            if ( i == 1 || i == 5 || i == 6) {
                drawerItems.add (new DrawerItem (mDrawerLayoutItemsNames[i], R.drawable.ic_home, false ) );
                drawerItems.add (new DrawerItem ("division", null, true ) );
            }
            else
                drawerItems.add (new DrawerItem (mDrawerLayoutItemsNames[i], R.drawable.ic_home, false) );
        }

        drawerItems.get(3).setIcon (R.drawable.ic_laboratory);
        drawerItems.get(4).setIcon (R.drawable.ic_imagenology);
        drawerItems.get(5).setIcon (R.drawable.ic_blood_bank);
        drawerItems.get(6).setIcon (R.drawable.ic_renal_care);
        drawerItems.get(8).setIcon (R.drawable.ic_cotization);
        drawerItems.get(10).setIcon (R.drawable.ic_sign_out);

        mDrawerList.setAdapter (new CustomAdapter ( this, drawerItems ) );

        mDrawerList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0:
                        if (sharedPref.getString("jwt", null) != null) {
                            //instaceStateBundle.putInt("fragment", ConfigParams.USER_PROF);
                           // instaceStateBundle.remove("scrollToPosition");
                            //go to user profile
                            break;
                        }
                    case 1:
                        instaceStateBundle.putInt("fragment", ConfigParams.MAIN_FRAGMENT);
                        mDrawerList.setSelection(1);
                        break;
                    case 3:
                        instaceStateBundle.putInt("fragment", ConfigParams.CLINIC_LABORATORY_FRAGMENT);
                        instaceStateBundle.putInt("divisionId", ConfigParams.CLINIC_LABORATORY_FRAGMENT );
                        break;
                    case 4:
                        instaceStateBundle.putInt("fragment", ConfigParams.IMAGENOLOGY_FRAGMENT);
                        instaceStateBundle.putInt("divisionId", ConfigParams.IMAGENOLOGY_FRAGMENT );
                        break;
                    case 5:
                        instaceStateBundle.putInt("fragment", ConfigParams.BLOOD_BANK_FRAGMENT);
                        instaceStateBundle.putInt("divisionId", ConfigParams.BLOOD_BANK_FRAGMENT );
                        break;
                    case 6:
                        instaceStateBundle.putInt("fragment", ConfigParams.RENAL_CARE_FRAGMENT);
                        instaceStateBundle.putInt("divisionId", ConfigParams.RENAL_CARE_FRAGMENT );
                        break;
                    case 10:
                        logOut();
                        break;

                }
                settingFragment(true, instaceStateBundle );
                mDrawerLayout.closeDrawers();

            }
        });
        toggle.syncState();
    }

    /*
    * Hide the keyboard
    * */
    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    private class CustomAdapter extends ArrayAdapter {

        ArrayList<DrawerItem> items;

        public CustomAdapter (Context context, List objects) {
            super (context, 0, objects);
            items = (ArrayList<DrawerItem>) objects;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

            if ( convertView == null ) {
                LayoutInflater inflater = (LayoutInflater) parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                if (position == 0){
                    convertView = inflater.inflate(R.layout.layout_drawer_user_data,null);
                }else{
                    if ( position == 2 || position == 7 || position == 9 )
                        convertView = inflater.inflate(R.layout.layout_drawer_division,null);
                    else
                        convertView = inflater.inflate(R.layout.layout_drawer_list_item,null);
                }
            }
            DrawerItem item = items.get(position);

            if ( position != 0 ) {

                if(position == 1 ){
                    LinearLayout layout = convertView.findViewById(R.id.drawer_list_item_layout);
                   //LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                   // layoutParams.setMargins(0,20,0,0);
                    layout.setPadding(0,40, 0,30);
                }

                if ( position != 2 && position != 7 && position != 9 ) {
                    ImageView icon = convertView.findViewById (R.id.iv_drawer_list_item_img);
                    icon.setImageResource (item.getIcon());
                    TextView name = convertView.findViewById(R.id.tv_drawer_list_item_name);
                    name.setText(item.getName());
                }
            }
            else {

                UserModel logged = UserModel.getUserLogged();
                TextView tv_drawer_user_fullname = convertView.findViewById(R.id.tv_drawer_user_fullname);
                TextView tv_drawer_user_email = convertView.findViewById(R.id.tv_drawer_user_email);
                ImageView iv_drawer_user_photo = convertView.findViewById(R.id.iv_drawer_user_photo);
                tv_drawer_user_fullname.setText(logged.getName() + "eu ");
                tv_drawer_user_email.setText(logged.getEmail());
                //iv_drawer_user_photo.setImageDrawable(logged.getLogoFromAssets());
                Log.d("message", logged.getPhoto() ) ;
                Picasso.get().load(logged.getPhoto()).placeholder(DicipaApp.MyContext.getResources().getDrawable(R.drawable.no_user_logged)).into(iv_drawer_user_photo);

            }

            return convertView;
        }
    }

    private void logOut () {

        AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
        adb.setTitle(R.string.menu_logout);
        adb.setMessage(R.string.logout_title);
        adb.setPositiveButton(R.string.btn_yes, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                attemptLogout();
            } });
        adb.setNegativeButton(R.string.btn_cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            } });
        adb.show();

    }

    public void attemptLogout() {

        SharedPreferences.Editor editor = DicipaApp.getPreferences().edit();
        editor.putString("session_user_keep_open",null);
        editor.putString("session_user",null);
        editor.putString("session_user_name",null);
        editor.putString("session_user_photo_name",null);
        editor.putString("session_user_email",null);
        editor.putString("session_user_username",null);

        editor.apply();
        mProgressDialog.setMessage(getBaseContext().getResources().getString(R.string.closing_session));
        mProgressDialog.show();
        //close remote session
        if ( sharedPref.getString("session_user_id", null) == null ) {

            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    // Do something after 5s = 5000ms
                    mProgressDialog.dismiss();
                    Intent intent = new Intent(MainActivity.this, SignInActivity.class);
                    startActivity(intent);
                    finish();
                }
            }, 2000);


        } else {
            mProgressDialog.dismiss();
        }
    }

    /*
     *
     * Shows a the image zoon dialog
     *
     * @param long id
     * @param int type
     * @param Bundle extra
     * */
    public void showImageZoomDialog ( Bundle data ) {

        FragmentManager fm = getSupportFragmentManager();
        ImageZoomDialogFragment imageZoomDialogFragment = ImageZoomDialogFragment.newInstance ( getResources().getString( R.string.left_menu_img ), data );
        imageZoomDialogFragment.show ( fm, "zoom_image_view_layout" );
    }

}
