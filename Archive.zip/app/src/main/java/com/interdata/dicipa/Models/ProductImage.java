package com.interdata.dicipa.Models;

import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;

import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.ConfigParams;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class ProductImage {

    private String id;
    private String name;
    private String description;
    private String file;

    private Drawable imageDrawable;

    public ProductImage(String id, String name, String description, String file) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.file = file;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Drawable getImageDrawable() {
        try {

            File filesdir = ContextCompat.getExternalFilesDirs(DicipaApp.MyActivity,null)[0];
            String photo = filesdir.getAbsolutePath() + "/" + ConfigParams.PRODUCTS_PATH + "/" + file;
            File archivo = new File(photo);
            if (archivo.isFile()) {
                Drawable drawable = Drawable.createFromPath(photo);
                return drawable;
            } else {
                try{
                    InputStream ims = DicipaApp.MyActivity.getAssets().open( ConfigParams.PRODUCTS_PATH + "/" + file );
                    Drawable drawable = Drawable.createFromStream(ims, null);
                    return drawable;
                }
                catch(IOException ex) {
                    ex.printStackTrace();
                }
            }

            InputStream defims = DicipaApp.MyActivity.getAssets().open("product_image.png");
            Drawable df = Drawable.createFromStream(defims, null);

            return df;

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;

    }

    public void setImageDrawable(Drawable imageDrawable) {
        this.imageDrawable = imageDrawable;
    }
}
