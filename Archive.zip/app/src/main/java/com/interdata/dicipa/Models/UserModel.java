package com.interdata.dicipa.Models;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;

import com.interdata.dicipa.Adapters.DatabaseAdapter;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.ConfigParams;
import com.interdata.dicipa.Persistence.DataBaseHelper;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class UserModel {

    public static String DB_TABLE_NAME = "usuarios";
    public static String DB_TABLE_PERSON = "personas";

    public static String DB_TABLE_NAME_ALIAS = "usr";

    public static String DB_INDEX_USER_ID = "id_usuario";
    public static String DB_INDEX_USER_ID_PERSON = "id_persona";
    public static String DB_INDEX_USER_ID_ROL = "id_rol";
    public static String DB_INDEX_USER_USERNAME = "usuario";
    public static String DB_INDEX_USER_PASSW = "clave";
    public static String DB_INDEX_USER_AUTH_KEY = "authKey";
    public static String DB_INDEX_USER_ACCESS_TOKEN = "accessToken";
    public static String DB_INDEX_USER_IS_ACTIVE = "esta_activo";
    public static String DB_INDEX_USER_LAST_ACCESS = "ultimo_acceso";

    public static String DB_INDEX_PERSON_EMAIL = "correo";
    public static String DB_INDEX_PERSON_NAME = "nombre";
    public static String DB_INDEX_PERSON_REGISTRATION_DATE = "fecha_registro";
    public static String DB_INDEX_PERSON_PHOTO = "foto";
    public static String DB_INDEX_PERSON_PHOTO_URL = "foto_url";

    private String id;
    private String username;
    private String password;
    private String photo;
    private String idRole;
    private String idPerson;
    private String authKey;
    private String accessKey;
    private int isActive;
    private String lastAccess;
    private PersonModel person;

    //shared preferences var
    private SharedPreferences sharedPref;

    //Database variables
    private SQLiteDatabase model;
    private DatabaseAdapter dbModel;

    public UserModel ( Context context  ) {

        dbModel = new DatabaseAdapter ( context );
        dbModel.open();
        model = dbModel.getmDb();
        sharedPref = DicipaApp.getPreferences();

    }

    public UserModel () {
        person = new PersonModel();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return person.getName();
    }

    public void setName( String name) {
        this.person.setName(name);
    }

    public String getEmail() {
        return person.getEmail();
    }

    public void setEmail(String email) {
        this.person.setEmail(email);
    }

    public String getPhoto() {
        return this.person.getPhoto();
    }

    public void setPhoto(String photo) {
        this.person.setPhoto(photo);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getIdRole() {
        return idRole;
    }

    public void setIdRole(String idRole) {
        this.idRole = idRole;
    }

    public String getAuthKey() {
        return authKey;
    }

    public void setAuthKey(String authKey) {
        this.authKey = authKey;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public int getIsActive() {
        return isActive;
    }

    public void setIsActive(int isActive) {
        this.isActive = isActive;
    }

    public String getLastAccess() {
        return lastAccess;
    }

    public void setLastAccess(String lastAccess) {
        this.lastAccess = lastAccess;
    }

    public String getIdPerson() {
        return idPerson;
    }

    public void setIdPerson(String idPerson) {
        this.idPerson = idPerson;
    }

    public PersonModel getPerson() {
        return person;
    }

    public void setPerson(PersonModel person) {
        this.person = person;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    /*
     * Gets the logo of the restaurant from assets
     *
     * @return Drawable
     * */
    public Drawable getLogoFromAssets () {


        try {
            if ( person.getPhoto() != null && ! person.getPhoto().equals("") ) {
                File filesdir = ContextCompat.getExternalFilesDirs(DicipaApp.getMyActivity(),null)[0];
                String avatar = filesdir.getAbsolutePath() + "/" + ConfigParams.USERS_PATH + "/" + person.getPhoto();
                File archivo = new File(avatar);
                if (archivo.isFile()) {
                    Drawable d = Drawable.createFromPath(avatar);
                    return d;
                }else{
                    try{
                        InputStream ims = DicipaApp.MyActivity.getAssets().open( ConfigParams.USERS_PATH + "/" + person.getPhoto() );
                        Drawable d = Drawable.createFromStream(ims, null);
                        return d;
                    }catch(IOException ex) {
                        InputStream defims = DicipaApp.MyActivity.getAssets().open("no_user_logged.png");
                        // load image as Drawable
                        Drawable pd = Drawable.createFromStream(defims, null);
                        return pd;
                    }
                }
            } else {
                // get input stream
                InputStream ims = DicipaApp.MyActivity.getAssets().open("no_user_logged.png");
                // load image as Drawable
                Drawable d = Drawable.createFromStream(ims, null);
                return d;
            }
        }
        catch(IOException ex) {
            return null;
        }
    }

    /*
     * Gets the logo of the restaurant from assets
     *
     * @return Drawable
     * */
    public boolean hasPhoto () {

        if (person.getPhoto() != null && !person.getPhoto().equals("") ) {
            File filesdir = ContextCompat.getExternalFilesDirs(DicipaApp.getMyActivity(),null)[0];
            String avatar = filesdir.getAbsolutePath() + "/" + ConfigParams.USERS_PATH + "/" + person.getPhoto();
            File archivo = new File(avatar);
            if (archivo.isFile()) {
                return true;
            }else{
                try{
                    InputStream ims = DicipaApp.MyActivity.getAssets().open( ConfigParams.USERS_PATH + "/" + person.getPhoto() );
                    Drawable d = Drawable.createFromStream(ims, null);
                    return true;
                }catch(IOException ex) {
                    return false;
                }
            }
        } else {
            return false;
        }

    }

    public static UserModel getUserLogged () {

        String id = DicipaApp.getPreferences().getString("session_user", "");
        String name = DicipaApp.getPreferences().getString("session_user_name", "");
        String imgName = DicipaApp.getPreferences().getString("session_user_photo", "");
        String email = DicipaApp.getPreferences().getString("session_user_email", "");
        String username = DicipaApp.getPreferences().getString("session_username", "");
        String type = DicipaApp.getPreferences().getString("session_username", "");
        String jwt = DicipaApp.getPreferences().getString("jwt", "");

        UserModel user = new UserModel ();
        user.setId(id);
        user.setName(name);
        user.setPhoto(imgName);
        user.setEmail(email);
        user.setUsername(username);
        user.setIdRole(type);
        user.setAuthKey(jwt);

        return user;

    }

    public static boolean existByPK (long key , SQLiteDatabase model) {
        try  {

            boolean exist = true;

            String sql = "SELECT * FROM usuarios usr " +
                    "WHERE usr.id = " + key;

            Cursor mCur = model.rawQuery(sql, null);

            if (mCur == null || mCur.getCount() == 0 )
                exist = false;

            mCur.close();

            return exist;

        }
        catch (SQLException mSQLException)
        {
            Log.e("existByPK >> ", mSQLException.toString());
            throw mSQLException;
        }
    }

    /*
     * Get user by email or username
     *
     * @param long key
     * @return UserModel */

    public UserModel findUser ( Bundle params ) {
        try  {

            String condition = "";
            String join = "";

            String sql = "SELECT * FROM " + DataBaseHelper.DB_TABLE_PREFIX + DB_TABLE_NAME + " AS " + DB_TABLE_NAME_ALIAS;
            join = " INNER JOIN " + DataBaseHelper.DB_TABLE_PREFIX + DB_TABLE_PERSON + " pe ON pe.id_persona = " + DB_TABLE_NAME_ALIAS + ".id_persona";
            sql += join;

            if ( params.get("authenticate") != null ) {
                condition = " WHERE (" + DB_TABLE_NAME_ALIAS + "." + DB_INDEX_USER_USERNAME + "='" + params.getString("authenticate") + "' OR pe.correo = '"+params.getString("authenticate")+"')";
            }

            sql+=condition;

            Cursor mCur = model.rawQuery(sql, null);

            if (mCur == null || mCur.getCount() == 0 )
                return null;

            mCur.moveToFirst();

            UserModel user = geUserAsObject ( mCur );

            mCur.close();

            return user;

        }
        catch (SQLException mSQLException)
        {
            Log.e(this.getClass().toString(), "findByPk >> "+ mSQLException.toString());
            throw mSQLException;
        }
    }

    /*
     * Gets the list of users
     *
     * @return List<UserModel>
     * */
    public List<UserModel> findAll ( Bundle bundle )
    {
        try
        {
            String condition = "";

            String sql = "SELECT * FROM " + DataBaseHelper.DB_TABLE_PREFIX + DB_TABLE_NAME + " AS " + DB_TABLE_NAME_ALIAS;

            //sort
            sql = sql + " ORDER BY "+DB_TABLE_NAME_ALIAS+"."+DB_INDEX_USER_ID+" ASC ";

            Cursor mCur = model.rawQuery(sql, null);

            List<UserModel> userList = new ArrayList<>();

            if (mCur==null)
                return userList;


            for (mCur.moveToFirst(); !mCur.isAfterLast(); mCur.moveToNext()) {
                UserModel user = geUserAsObject ( mCur  );
                userList.add( user );
            }
            mCur.close();

            return userList;
        }
        catch (SQLException mSQLException)
        {
            Log.e(this.getClass().toString(), "findAll >> "+ mSQLException.toString());
            throw mSQLException;
        }
    }

    /*
     * Gets the user object by cursor position
     *
     * @param Cursor cursor
     * @return UserModel
     *
     * */
    public UserModel geUserAsObject ( Cursor cursor ) {

        UserModel user = new UserModel ( );

        //BASICS
        int idUserIndex = cursor.getColumnIndex( DB_INDEX_USER_ID );
        int idPersonIndex = cursor.getColumnIndex( DB_INDEX_USER_ID_PERSON );
        int idRolIndex = cursor.getColumnIndex( DB_INDEX_USER_ID_ROL );
        int usernameIndex = cursor.getColumnIndex( DB_INDEX_USER_USERNAME );
        int passwIndex = cursor.getColumnIndex( DB_INDEX_USER_PASSW );
        int authKeyIndex = cursor.getColumnIndex( DB_INDEX_USER_AUTH_KEY );
        int accessTokenIndex = cursor.getColumnIndex( DB_INDEX_USER_ACCESS_TOKEN );
        int isActiveIndex = cursor.getColumnIndex( DB_INDEX_USER_IS_ACTIVE);
        int lastAccessIndex = cursor.getColumnIndex( DB_INDEX_USER_LAST_ACCESS);

        int personNameIndex = cursor.getColumnIndex( DB_INDEX_PERSON_NAME);
        int emailIndex = cursor.getColumnIndex( DB_INDEX_PERSON_EMAIL);
        int registrationDate = cursor.getColumnIndex( DB_INDEX_PERSON_REGISTRATION_DATE );
        int photoIndex = cursor.getColumnIndex( DB_INDEX_PERSON_PHOTO );
        int photoUrlIndex = cursor.getColumnIndex( DB_INDEX_PERSON_PHOTO );

        //fetch data from cursor..
        user.setId ( String.valueOf( cursor.getLong ( idUserIndex ) ) );
        user.setIdRole ( String.valueOf ( cursor.getLong ( idRolIndex ) ) );
        user.setUsername ( cursor.getString ( usernameIndex  ) );
        user.setAccessKey ( cursor.getString ( accessTokenIndex ) );
        user.setAuthKey ( cursor.getString ( authKeyIndex  ) );
        user.setIsActive ( cursor.getInt( isActiveIndex ) );
        user.setLastAccess ( cursor.getString ( lastAccessIndex  ) );
        user.setUsername ( cursor.getString ( usernameIndex  ) );
        user.setPassword( cursor.getString ( passwIndex ) );


        PersonModel person = new PersonModel();
        person.setId ( String.valueOf ( cursor.getLong ( idPersonIndex ) ) );
        person.setName ( cursor.getString ( personNameIndex ) );
        person.setEmail( cursor.getString ( emailIndex ) );
        person.setRegistration_date ( cursor.getString ( registrationDate ) );
        person.setPhoto ( cursor.getString ( photoIndex ) );
        person.setPhotoUrl ( cursor.getString ( photoUrlIndex ) );
        user.setPerson( person );

        return user;

    }


}
