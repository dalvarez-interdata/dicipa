package com.interdata.dicipa.Models;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;

import com.interdata.dicipa.Adapters.DatabaseAdapter;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Persistence.DataBaseHelper;

import java.util.ArrayList;
import java.util.List;

/*
 * ProductModel model
 * @auhor Deivis Ricardo
 * @date 15/03/2019*/

public class ProductModel {

    private String id;
    private String name;
    private String model;
    private String description;
    private String techincalDescription;
    private String price;
    private int antecesor;
    private List<String> images;
    private List<CategoryDivisionModel> categories;

    public static String DB_TABLE_NAME = DataBaseHelper.DB_TABLE_PREFIX +  "productos";
    public static String DB_TABLE_NAME_ALIAS = "ptos";

    public static String DB_TABLE_JOIN_CATEGORY =  DataBaseHelper.DB_TABLE_PREFIX + "relacion_productos_categorias";
    public static String DB_TABLE_CATEGORY_INDEX = "id_categoria";
    public static String DB_TABLE_CATEGORY_ALIAS = "rp_ca";

    public static String DB_INDEX_PRODUCT_ID = "id_producto";
    public static String DB_INDEX_PRODUCT_NAME = "producto";
    public static String DB_INDEX_PRODUCT_DESC = "descripcion";
    public static String DB_INDEX_PRODUCT_TESH_DESC = "descripcionTecnica";
    public static String DB_INDEX_PRODUCT_SUGGESTED_PRICE = "precio_sugerido";
    public static String DB_INDEX_PRODUCT_ANTECESOR = "id_anterior";


    //shared preferences var
    private SharedPreferences sharedPref;

    //Database variables
    private SQLiteDatabase modelDB;
    private DatabaseAdapter dbModel;

    public ProductModel() {
    }

    public ProductModel (Context context ) {
        dbModel = new DatabaseAdapter( context );
        dbModel.open();
        modelDB = dbModel.getmDb();
        sharedPref = DicipaApp.getPreferences();

    }

    public ProductModel(String id, String name, String model, String description, List<String> images, List<CategoryDivisionModel> categories) {
        this.id = id;
        this.name = name;
        this.model = model;
        this.description = description;
        this.images = images;
        this.categories = categories;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<String> getImages() {
        return images;
    }

    public void setImages(List<String> images) {
        this.images = images;
    }

    public List<CategoryDivisionModel> getCategories() {
        return categories;
    }

    public void setCategories(List<CategoryDivisionModel> categories) {
        this.categories = categories;
    }

    public String getTechincalDescription() {
        return techincalDescription;
    }

    public void setTechincalDescription(String techincalDescription) {
        this.techincalDescription = techincalDescription;
    }

    public int getAntecesor() {
        return antecesor;
    }

    public void setAntecesor(int antecesor) {
        this.antecesor = antecesor;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    /*
     * Gets the list products
     *
     * @return List<ProductModel>
     * */
    public List<ProductModel> findAll (Bundle bundle )
    {
        try
        {
            String condition = "";
            String join = "";

            String sql = "SELECT * FROM " + DB_TABLE_NAME + " AS " + DB_TABLE_NAME_ALIAS;

            if ( bundle.get("category") != null ) {
                join+= " INNER JOIN " + DB_TABLE_JOIN_CATEGORY + " " + DB_TABLE_CATEGORY_ALIAS + " ON " + DB_TABLE_CATEGORY_ALIAS + "." + DB_INDEX_PRODUCT_ID + "=" + DB_TABLE_NAME_ALIAS + "." + DB_INDEX_PRODUCT_ID;
                condition+= " WHERE " + DB_TABLE_CATEGORY_ALIAS+ "." + DB_TABLE_CATEGORY_INDEX + "=" + bundle.getString("category");
            }

            sql += join;
            sql += condition;


            //sort
            sql = sql + " ORDER BY "+DB_TABLE_NAME_ALIAS+"."+DB_INDEX_PRODUCT_ID+" ASC ";

            Cursor mCur = modelDB.rawQuery ( sql, null);

            List<ProductModel> productsList = new ArrayList<>();

            if (mCur==null)
                return productsList;

            for (mCur.moveToFirst(); !mCur.isAfterLast(); mCur.moveToNext()) {
                ProductModel product = getProductAsObject ( mCur );
                productsList.add( product );
            }
            mCur.close();

            return productsList;
        }
        catch (SQLException mSQLException)
        {
            Log.e(this.getClass().toString(), "findAll >> "+ mSQLException.toString());
            throw mSQLException;
        }
    }

    /*
     * Gets the product object by cursor position
     *
     * @param Cursor cursor
     * @return ProductModel
     *
     * */
    public ProductModel getProductAsObject ( Cursor cursor ) {

        ProductModel product = new ProductModel ();

        //BASICS
        int idProductIndex = cursor.getColumnIndex( DB_INDEX_PRODUCT_ID );
        int productNameIndex = cursor.getColumnIndex( DB_INDEX_PRODUCT_NAME );
        int productTechDescIndex = cursor.getColumnIndex( DB_INDEX_PRODUCT_TESH_DESC );
        int productDescIndex = cursor.getColumnIndex( DB_INDEX_PRODUCT_DESC );
        int productPriceIndex = cursor.getColumnIndex( DB_INDEX_PRODUCT_SUGGESTED_PRICE );
        int productAntIndex = cursor.getColumnIndex( DB_INDEX_PRODUCT_ANTECESOR );

        //id
        long id = cursor.getLong ( idProductIndex );
        product.setId ( String.valueOf(id) );
        product.setName ( cursor.getString ( productNameIndex ) );
        product.setDescription ( cursor.getString ( productDescIndex )  );
        product.setTechincalDescription ( cursor.getString ( productTechDescIndex ) );
        product.setPrice ( cursor.getString ( productPriceIndex ) );
        product.setAntecesor ( cursor.getInt ( productAntIndex ) );

        return product;

    }


}
