package com.interdata.dicipa.Webservices;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.content.ContextCompat;
import android.util.JsonReader;
import android.util.Log;

import com.interdata.dicipa.Adapters.DatabaseAdapter;
import com.interdata.dicipa.ConfigParams;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Models.UserModel;
import com.interdata.dicipa.R;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by Ppyonki on 09/01/2017.
 * Modified by Deivis 04/15/2019.
 */
public class WebServiceJSONParser {

    private SharedPreferences prefs;
    //Database variables
    private SQLiteDatabase model;
    private DatabaseAdapter dbModel;
    private Context context;
    static JSONObject jObj = null;
    static String json = "";

    public WebServiceJSONParser(Context context){
        this.context = context;
        prefs = this.context.getSharedPreferences("DicipaPrefs", Context.MODE_PRIVATE);
        //dbModel = new DatabaseAdapter( contexto );
        //dbModel.open();
        //model = dbModel.getmDb();
    }

    public OperationResult readJsonStreamNotification (InputStream wsResult) throws IOException {

        JsonReader reader = new JsonReader(new InputStreamReader(wsResult, "UTF-8"));

        try {
            return readDataObjectNotification(reader);
        } finally {
            reader.close();
        }
    }



  public OperationResult readDataObjectNotification ( JsonReader reader) throws IOException{

        //Fecha de actualizacion
        String fecha = null;
        //Datos enviados para procesar
        List notifications = new ArrayList<>();

        reader.beginArray();
        while (reader.hasNext()) {
            //notifications.add(readNreadNotification(reader));
        }
        reader.endArray();

        OperationResult result = new OperationResult ( ConfigParams.NOTIFICATIONS_POST );

        //SharedPreferences.Editor editor = prefs.edit();
        //editor.putString(ConfigParams.PREFS_UPDATE_DATE ,fecha);
        //editor.apply();
        //GlobalMarkApp.notifications = notifications;

        result.setmCode(OperationResult.ResultCode.OK);

        return result;
    }

    /*
     * * Read notification from json

    public NotificationModel readNreadNotification (JsonReader reader) throws IOException {
        NotificationModel notification = new NotificationModel(null, null, null, null, null);
        UserModel user = null;
        String id = "-1";
        String action = null;
        String date = null;
        String postId = null;

        reader.beginObject();
        while (reader.hasNext()) {
            String key = reader.nextName();
            if (key.equals("user")) {
                try {
                    int idUser = -1;
                    String username = null;
                    String email = null;
                    String name = null;
                    String title = null;
                    String img = null;
                    String imgName = null;

                    reader.beginObject();
                    while (reader.hasNext()) {
                        String okey = reader.nextName();
                        if (okey.equals("id")) idUser = reader.nextInt();
                        else if (okey.equals("username")) username = reader.nextString();
                        else if (okey.equals("email")) email = reader.nextString();
                        else if (okey.equals("name")) name = reader.nextString();
                        else if (okey.equals("title")) title = reader.nextString();
                        else if (okey.equals("pic")) imgName = reader.nextString();
                        else if (okey.equals("image")) img = reader.nextString();
                        else reader.skipValue();
                    }
                    reader.endObject();
                    user = new UserModel();
                    user.setId(idUser);
                    user.setUsername(username);
                    user.setEmail(email);
                    user.setName(name);
                    user.setTitle(title);
                    user.setPhoto(imgName);
                    user.setPhotoUrl(img);

                } catch ( Exception e ) {
                    Log.d("message", e.getMessage() + "<>");
                }

            }
            else if (key.equals("id")) {id = reader.nextString(); }
            else if (key.equals("action")) action = reader.nextString();
            else if (key.equals("date")) date = reader.nextString();
            else if (key.equals("post")) postId = reader.nextString();
            else {reader.skipValue();}
        }
        reader.endObject();

        notification.setId(id);
        notification.setText (action);
        notification.setDate (date);
        notification.setUser(user);
        notification.setPostId(postId);

        return notification;
    }*/


    public OperationResult readJsonStreamLogin(InputStream wsResult) throws IOException {

        JsonReader reader = new JsonReader(new InputStreamReader(wsResult, "UTF-8"));
        OperationResult result = new OperationResult(ConfigParams.SERVICE_LOGIN);

        try {
            String jwt = null;
            String error = null;
            Boolean status = false;
            String message = null;

            int id = -1;
            String username = null;
            String email = null;
            String name = null;
            String father_lastname = null;
            String mother_lastname = null;
            String photo = null;
            String token = null;
            String type = null;


            reader.beginObject();
            while (reader.hasNext()){
                String key = reader.nextName();
                if (key.equals("status")) status = reader.nextBoolean();
                else if (key.equals("message")) message = reader.nextString();
                else if (key.equals("error")) error = reader.nextString();
                else if (key.equals("jwt")) {
                    reader.beginObject();
                    while (reader.hasNext()){
                        String jwtObject = reader.nextName();
                        if (jwtObject.equals("token")) token = reader.nextString();
                        else if ( jwtObject.equals("data") ) {
                            reader.beginObject();
                            while (reader.hasNext()) {
                                String jwtObjectData = reader.nextName();
                                if (jwtObjectData.equals("id")) id = reader.nextInt();
                                else if (jwtObjectData.equals("username")) username = reader.nextString();
                                else if (jwtObjectData.equals("name")) name = reader.nextString();
                                else if (jwtObjectData.equals("father_lastname")) father_lastname = reader.nextString();
                                else if (jwtObjectData.equals("mother_lastname")) mother_lastname = reader.nextString();
                                else if (jwtObjectData.equals("photo")) photo = reader.nextString();
                                else if (jwtObjectData.equals("type")) type = reader.nextString();
                                else reader.skipValue();
                            }
                            reader.endObject();
                        }
                        else reader.skipValue();
                    }
                    reader.endObject();
                }
                else reader.skipValue();
            }
            reader.endObject();

            if( status && id > 0 && error == null ) {

                UserModel user = new UserModel();
                user.setId ( String.valueOf ( id ) );
                user.setName ( name + " " + father_lastname + " " + mother_lastname );
                user.setEmail ( email );
                user.setPhoto ( photo );
                user.setIdRole ( type );
                user.setUsername ( username );

                SharedPreferences.Editor editor = DicipaApp.getPreferences().edit();

                editor.putString("session_user",String.valueOf(id));
                editor.putString("session_user_name",user.getName());
                editor.putString("session_user_photo",user.getPhoto());
                editor.putString("session_user_email",user.getEmail());
                editor.putString("session_username",username);
                editor.putString("session_user_type",type);
                editor.putString("jwt", token);

                editor.apply();

                result.setmCode(OperationResult.ResultCode.RESULT_SUCCESS);
            }
            else {
                result.setmCode(OperationResult.ResultCode.OAUTH2_ERROR_ACCESS_DENIED);
            }

            return result;

        } catch ( Exception e ){
            Log.d("message", e.getMessage() + e.getCause());
            e.printStackTrace();
            reader.close();
        }
        result.setmCode(OperationResult.ResultCode.JSON_EXCEPTION);

        return result;
    }

    /*
    * User profile */

    public OperationResult readJsonStreamUserProfile (InputStream wsResult) throws IOException {

        JsonReader reader = new JsonReader(new InputStreamReader(wsResult, "UTF-8"));
        OperationResult result = new OperationResult(ConfigParams.SERVICE_USER_PROFILE);

        try {
            String jwt = null;
            int id = -1;
            String username = null;
            String email = null;
            String name = null;
            String title = null;
            String img = null;
            String imgName = null;
            String error = null;
            String posts = null;
            String projects = null;
            String contacts = null;
            String phones = null;
            String bio = null;
            String study_level= null;
            String ocupation= null;
            String profesion= null;
            String work_experience= null;
            String interests= null;
            String empresa = null;
            //List<UserModel> contactsList = new ArrayList<>();


            reader.beginObject();
            while (reader.hasNext()){
                String key = reader.nextName();
                if (key.equals("id") ) id = reader.nextInt();
                else if (key.equals("username")) username = reader.nextString();
                else if (key.equals("email") ) email = reader.nextString();
                else if (key.equals("name") ) name = reader.nextString();
                else if (key.equals("title") ) title = reader.nextString();
                else if (key.equals("pic") ) imgName = reader.nextString();
                else if (key.equals("image") ) img = reader.nextString();
                else if (key.equals("posts") ) posts = reader.nextString();
                else if (key.equals("projects") ) projects = reader.nextString();
                else if (key.equals("contacts") ) contacts = reader.nextString();
                else if (key.equals("phone") ) phones = reader.nextString();
                else if (key.equals("bio") ) bio = reader.nextString();
                else if (key.equals("study_level") ) study_level = reader.nextString();
                else if (key.equals("ocupation") ) ocupation = reader.nextString();
                else if (key.equals("profesion") ) profesion = reader.nextString();
                else if (key.equals("work_experience") ) work_experience = reader.nextString();
                else if (key.equals("interests") ) interests = reader.nextString();
                else if (key.equals("empresa") ) empresa = reader.nextString();
                else if (key.equals("error") ) error = reader.nextString();
                else reader.skipValue();
            }
            reader.endObject();


            if(id > 0 && error == null ) {

                /*UserModel user = new UserModel();
                user.setId(id);
                user.setUsername(username);
                user.setEmail(email);
                user.setName(name);
                user.setTitle(title);
                user.setPhoto(img);
                user.setTelephone(phones);
                user.setCountContacts(contacts);
                user.setCountProjects(projects);
                user.setCountPublications(posts);
                user.setBio(bio);
                user.setStudy_level(study_level);
                user.setProfesion(profesion);
                user.setOcupation(ocupation);
                user.setWork_experience(work_experience);
                user.setInterests(interests);
                user.setEmpresa(empresa);
                user.setContacts(contactsList);

                GlobalMarkApp.userProfile = user;*/

                result.setmCode(OperationResult.ResultCode.RESULT_SUCCESS);
            }
            else {
                result.setmCode(OperationResult.ResultCode.OAUTH2_ERROR_ACCESS_DENIED);
            }

            return result;

        } catch ( Exception e ){
            Log.d("message", e.getMessage());
            reader.close();
        }
        result.setmCode(OperationResult.ResultCode.JSON_EXCEPTION);

        return result;
    }


    public OperationResult readActionJsonStream  (InputStream wsResult) throws IOException {

        OperationResult result = new OperationResult(ConfigParams.SERVICE_ACTION);
        JsonReader reader = new JsonReader(new InputStreamReader(wsResult, "UTF-8"));
        try {
            boolean success = false;
            String error = null;

            reader.beginObject();
            while (reader.hasNext()){
                String key = reader.nextName();
                if (key.equals("success") ) {success = true;reader.nextString();}
                else if (key.equals("error") ) error = reader.nextString();
                else reader.skipValue();
            }
            reader.endObject();
            if( !success ){
                DicipaApp.error = true;
                DicipaApp.messageError = error;
                result.setmCode(OperationResult.ResultCode.SERVICE_ERROR);
            } else {
                result.setmCode(OperationResult.ResultCode.RESULT_SUCCESS);
                return result;
            }

            return result;

        } catch ( Exception e ){
            DicipaApp.error = true;
            DicipaApp.messageError = DicipaApp.MyContext.getString(R.string.service_error);
            reader.close();
        }

        result.setmCode(OperationResult.ResultCode.SERVICE_ERROR);
        return result;
    }


    public OperationResult readJsonStreamConfirmRecoverPassword (InputStream wsResult) throws IOException {

        OperationResult result = new OperationResult(ConfigParams.SERVICE_RECOVER_PASSWORD);
        JsonReader reader = new JsonReader(new InputStreamReader(wsResult, "UTF-8"));
        try {
            String coderegister = "";
            String emailregister = "";
            String error = null;

            reader.beginObject();
            while (reader.hasNext()){
                String key = reader.nextName();
                if (key.equals("code")) coderegister = reader.nextString();
                else if (key.equals("email_register")) emailregister = reader.nextString();
                else if (key.equals("error")) error = reader.nextString();
                else reader.skipValue();
            }
            reader.endObject();

            if( coderegister.length() > 0 ){
                SharedPreferences.Editor editor = DicipaApp.getPreferences().edit();
                editor.putString("session_code_confirmation_recover",coderegister);
                editor.putString("session_code_email_recover",emailregister);
                editor.apply();
                result.setmCode(OperationResult.ResultCode.RESULT_SUCCESS);

            } else {

                DicipaApp.error = true;
                DicipaApp.messageError = error;
                result.setmCode(OperationResult.ResultCode.SERVICE_ERROR);
            }

            return result;

        } catch ( Exception e ){
            Log.d("message", e.getMessage());
            DicipaApp.error = true;
            DicipaApp.messageError = DicipaApp.MyContext.getString(R.string.service_error);
            reader.close();
        }

        result.setmCode(OperationResult.ResultCode.SERVICE_ERROR);

        return result;
    }


    /*
     * Este metodo se encarga de procesar las imagenes
     */
    public void parseImage (InputStream wsResult, String imageName, String destination){

        if ( !imageName.equals("no_user_image.jpg") ) {

            File filesdir = ContextCompat.getExternalFilesDirs(DicipaApp.MyActivity, null)[0];
            String logopath = filesdir.getAbsolutePath() + "/" + destination;
            File file = new File(logopath);
            if (!file.isDirectory())
                file.mkdir();
            File fimage = new File(logopath + "/" + imageName);
            Bitmap bitmap = BitmapFactory.decodeStream(wsResult);
            Bitmap escalado = Bitmap.createScaledBitmap(bitmap, 96, 96, true);
            try {
                FileOutputStream out = new FileOutputStream(fimage);
                if (escalado.compress(Bitmap.CompressFormat.JPEG, 100, out))
                out.flush();
                out.close();
            } catch (Exception e) {
                Log.d("message", e.getMessage());
            }

        }
    }

}
