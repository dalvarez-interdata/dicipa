package com.interdata.dicipa;

/**
 * Created by Deivis on 12/28/18.
 */

public class ConfigParams {

    public static final int MAIN_FRAGMENT = 20;
    public static final int CLINIC_LABORATORY_FRAGMENT = 1;
    public static final int IMAGENOLOGY_FRAGMENT = 3;
    public static final int BLOOD_BANK_FRAGMENT = 2;
    public static final int RENAL_CARE_FRAGMENT = 4;

    public static final int CATEGORY_DIVISION_DETAIL_FRAGMENT = 21;

    public static final boolean DEBUG_MODE = true;
    public static final String DEV_WEBSITE_BASE_URL = "http://www.dicipa.com.mx/";
    public static final String WEBSITE_BASE_URL = "https://dicipa.interdatamkt.com/";

    public static final String PREFERENCE_LANGUAGE_KEY = "language";
    public static final String PREFERENCE_LANGUAGE_EN = "en";
    public static final String PREFERENCE_LANGUAGE_ES = "es";

    public static final String PREFERENCE_DEFAULT_INTERFACE_KEY = "home";
    public static final String APP_USERS_PATH = "users";

    public static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 1;
    public static final int MY_PERMISSIONS_REQUEST_INTERNET = 1;
    public static final int MY_ACCESS_WIFI_STATE = 1;
    public static final int MY_ACCESS_FINE_LOCATION = 1;
    public static final int MY_ACCESS_COARSE_LOCATION = 1;
    public static final int MY_ACCESS_NETWORK_STATE = 1;
    public static final int MY_ACCESS_LOCATION_EXTRA_COMMANDS = 1;

    public static final int DOWNLOAD_IMAGE = 1;
    public static final int SERVICE_LOGIN = 2;
    public static final int RESEND_CODE = 3;
    public static final int SERVICE_RECOVER_PASSWORD = 4;
    public static final int SERVICE_USER_PROFILE = 5;
    public static final int NOTIFICATIONS_POST = 6;
    public static final int SERVICE_ACTION = 7;

    public static final String USERS_PATH = "users";
    public static final String PRODUCTS_PATH = "products";
    public static final String LOCAL_ASSETS_FOLDER =  "/dicipa";

    //web services related data
    public static final int TIMEOUT_HTTP_REQUEST = 0;
    public static final String HTTP_POST = "POST";
    public static final String HTTP_GET = "GET";
    public static final int DOWNLOAD_INFO = 1100;

    public static final String AUTH_TOKEN = "861324222614604";
    public static final String TAG_ERROR = "ERROR";
    public static final String MSG_ERROR = "MSG_ERROR";
    public static final String MSG_SUCCESS = "MSG_SUCCES";
    public static final String PREFS_UPDATE_DATE = "update_date";
    public static final String COMPILATION_DATA_VERSION = "25";
    public static final String COMPILATION_UPDATE_DATE = "2019-03-12 16:00:00";
    public static final String HTML_PARAM_AUTH_TOKEN = "auth_token";
    public static final String TAG_SUCCESS = "SUCCESS";
    public static final int HTTP_HOST_CONNECT_EXCEPTION = 7;

}
