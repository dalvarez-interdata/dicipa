package com.interdata.dicipa.Fragments;

import android.app.Dialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.interdata.dicipa.Activities.MainActivity;
import com.interdata.dicipa.ConfigParams;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Models.CategoryDivisionModel;
import com.interdata.dicipa.Models.DivisionModel;
import com.interdata.dicipa.Models.VolumenTestModel;
import com.interdata.dicipa.R;

import java.util.List;

import io.apptik.widget.MultiSlider;

public class SubcategoryDialogFragment extends DialogFragment {

    private  Bundle data;
    public static Handler myHandler;
    public DivisionModel model;

    List<CategoryDivisionModel> subcategories;

    ProgressBar loading;

    public static SubcategoryDialogFragment newInstance(String title, Bundle data) {

        SubcategoryDialogFragment frag = new SubcategoryDialogFragment();

        Bundle args = data;
        args.putString("title", title);
        frag.setArguments(args);

        return frag;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        Dialog dialog = super.onCreateDialog(savedInstanceState);

        // request a window without the title
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);

        return dialog;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.subcategory_dialog_layout, container);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {

        data = getArguments();
        getDialog().setTitle(data.getString("title"));
        getDialog().setCanceledOnTouchOutside(true);
        settingInterface ();

        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void onResume() {

        // Store access variables for window and blank point
        Window window = getDialog().getWindow();
        Point size = new Point();
        // Store dimensions of the screen in `size`
        Display display = window.getWindowManager().getDefaultDisplay();
        display.getSize(size);
        // Set the width of the dialog proportional to 75% of the screen width
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        window.setGravity(Gravity.CENTER);
        // Call super onResume after sizing

        super.onResume();
    }

    private void settingInterface () {

        TextView btn_close = getView().findViewById(R.id.btn_cancel_action);

        TextView tv_category_parent = getView().findViewById(R.id.tv_category_parent);
        tv_category_parent.setText(data.getString("divisionName"));

        TextView test_current_category = getView().findViewById(R.id.test_current_category);
        test_current_category.setText(data.getString("categoryName"));

        test_current_category.setText( test_current_category.getText() + " / " + data.getString("subcategoryName") );

        btn_close.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                data.putInt("button", 0);
                DicipaApp.data = data;
                dismiss();
            }
        });

        TextView btn_ok = getView().findViewById(R.id.btn_ok_action);
        btn_ok.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                data.putInt("button", 1);
                DicipaApp.data = data;
                dismiss();
            }
        });


        loading = getView().findViewById(R.id.loading_indication);
        model = new DivisionModel( DicipaApp.MyContext );
        final LinearLayout rootParent = getView().findViewById(R.id.ly_content);
        getCategories ( data.getString("subcategory"), rootParent, true );


    }

    /*
    * get subcategories by tap*/

    private void getCategories ( final String parent, final LinearLayout container, final boolean firstLine ) {

        myHandler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                loading.setVisibility(View.GONE);
                if ( subcategories.size() > 0 ) {
                    container.setVisibility(View.VISIBLE);
                    buildTree (  subcategories,  container, firstLine);
                } else {
                    //reenviar a productos;
                    DicipaApp.data = new Bundle();
                    DicipaApp.data.putInt("fragment", ConfigParams.CATEGORY_DIVISION_DETAIL_FRAGMENT);
                    DicipaApp.data.putString("id", data.getString("category") );
                    DicipaApp.data.putString("categoryName", data.getString("categoryName") );
                    DicipaApp.data.putString("divisionId",  data.getString("division") );
                    DicipaApp.data.putString("divisionName", data.getString("divisionName")  );
                    DicipaApp.data.putInt("button", 1);
                   // ((MainActivity) DicipaApp.MyActivity ).settingFragment(true, data);
                    dismiss();

                }
            }
        };

        loading.setVisibility(View.VISIBLE);
        new Thread(new Runnable() {
            public void run() {
                Bundle params = new Bundle ();
                params.putString ( "parent", parent);
                subcategories = model.getAllCategoriesByParams ( params );
                Message msg = myHandler.obtainMessage();
                myHandler.sendMessage(msg);
            }
        }).start();

    }


    private void buildTree (  List<CategoryDivisionModel> subcategories, LinearLayout viewParent, boolean firstLine ) {

        viewParent.removeAllViews();
        for (int i = 0; i < subcategories.size(); i++ ) {

            final CategoryDivisionModel category = subcategories.get(i);

            LinearLayout ly_wrapper = new LinearLayout( DicipaApp.MyContext);
            ly_wrapper.setOrientation(LinearLayout.HORIZONTAL);

            View divider = new View(DicipaApp.MyContext);
            LinearLayout.LayoutParams layoutParamsView = new LinearLayout.LayoutParams(96, 96);
            layoutParamsView.setMargins(0,20,10,10);
            divider.setLayoutParams(layoutParamsView);

            if ( DicipaApp.MyFragment instanceof ImagenologyFragment )
                divider.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.shape_circle_imagenology));
            else if ( DicipaApp.MyFragment instanceof RenalCareFragment )
                divider.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.shape_circle_renal));
            else if ( DicipaApp.MyFragment instanceof BloodBankFragment )
                divider.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.shape_circle_blood_bank));

            ly_wrapper.addView (divider);

            TextView sub = new TextView(DicipaApp.MyContext);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(20,30,10,10);
            sub.setLayoutParams ( layoutParams );
            sub.setText(subcategories.get(i).getName());
            sub.setTextColor(DicipaApp.MyContext.getResources().getColor(R.color.colorAccent));
            sub.setTextSize(15);
            ly_wrapper.addView (sub);

            if ( firstLine ) {
                View v = new View(DicipaApp.MyContext);
                LinearLayout.LayoutParams layoutParamsView2 = new LinearLayout.LayoutParams(6, 70);
                layoutParamsView2.setMargins(40,10,10,0);
                v.setLayoutParams(layoutParamsView2);
                v.setBackgroundColor(DicipaApp.MyContext.getResources().getColor(R.color.elementsDivider));
                viewParent.addView ( v );
            }

            viewParent.addView ( ly_wrapper );

            final LinearLayout subcategories_content = new LinearLayout(DicipaApp.MyContext);
            subcategories_content.setPadding(100,10,10,10);
            subcategories_content.setOrientation(LinearLayout.VERTICAL);
            viewParent.addView ( subcategories_content );
            subcategories_content.setVisibility(View.GONE);

            ly_wrapper.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    if ( subcategories_content.getVisibility() == View.GONE ) {
                        getCategories ( category.getId(), subcategories_content, true );
                    } else {
                        subcategories_content.setVisibility(View.GONE);
                    }
                }
            });
        }

    }




    private void doAction () {


    }

    @Override
    public void onDismiss(final DialogInterface dialog) {
        super.onDismiss(dialog);

        if (DicipaApp.data != null && DicipaApp.data.get("button") == null )
            DicipaApp.data.putInt("button", 0);

        final Fragment fragment = DicipaApp.MyFragment;
        if (fragment instanceof DialogInterface.OnDismissListener) {
            ((DialogInterface.OnDismissListener) fragment).onDismiss(dialog);
        }
    }



}
