package com.interdata.dicipa.Webservices;

import android.os.Bundle;
import android.os.Message;

import com.interdata.dicipa.ConfigParams;
import com.interdata.dicipa.DicipaApp;


public class SendHandlerMessage {

	static public void sendErrorMessage(int tag_value, String msg) {
		Bundle b = new Bundle();
		b.putInt(ConfigParams.TAG_ERROR, tag_value);
		b.putString(ConfigParams.MSG_ERROR, msg);

		Message msgObj = DicipaApp.my_handler.obtainMessage();
		msgObj.setData(b);
        DicipaApp.my_handler.sendMessage(msgObj);
	}

	static public void sendSuccesMessage(int operation , int msg) {
		Bundle b = new Bundle();
		b.putInt(ConfigParams.TAG_SUCCESS, operation);
		b.putInt(ConfigParams.MSG_SUCCESS, msg);

		Message msgObj = DicipaApp.my_handler.obtainMessage();
		msgObj.setData(b);
        DicipaApp.my_handler.sendMessage(msgObj);
	}
}
