package com.interdata.dicipa.Adapters;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.interdata.dicipa.Persistence.DataBaseHelper;


import java.io.IOException;

/**
 * Created by Deivis on 05/15/2019.
 */

public class DatabaseAdapter {

    protected static final String TAG = "DatabaseAdapter";

    private final Context mContext;
    private SQLiteDatabase mDb;
    private DataBaseHelper mDbHelper;

    public DatabaseAdapter(Context context)  {
        this.mContext = context;
        mDbHelper = new DataBaseHelper(mContext);
    }

    public DatabaseAdapter createDatabase () throws SQLException  {
        try {

            mDbHelper.createDataBase();

        }
        catch (IOException mIOException) {
            Log.e(TAG, mIOException.toString() + "  UnableToCreateDatabase");
            throw new Error("UnableToCreateDatabase");
        }
        return this;
    }

    public DatabaseAdapter open() throws SQLException {
        try {
            mDbHelper.openDataBase();
            mDbHelper.close();
            mDb = mDbHelper.getReadableDatabase();
        }
        catch (SQLException mSQLException) {
            Log.e(TAG, "open >> "+ mSQLException.toString());
            throw mSQLException;
        }
        return this;
    }

    public void close()
    {
        mDbHelper.close();
    }

    public SQLiteDatabase getmDb() {
        return mDb;
    }

    public DataBaseHelper getmDbHelper() {
        return mDbHelper;
    }

}
