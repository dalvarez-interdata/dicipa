package com.interdata.dicipa.Tools;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.interdata.dicipa.ConfigParams;

import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.RunnableFuture;

import static android.content.ContentValues.TAG;
import static java.lang.Thread.sleep;

public class NetworkUtils {
    public static final int STATUS_CONNECTED = 0 ;
    private static boolean hay_internet = false;

    public static boolean isInternetAvailable(Context ctx){
        ConnectivityManager cm = (ConnectivityManager)ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        return activeNetwork != null && activeNetwork.isConnectedOrConnecting();
    }

    public static int isInternetActiveWithPing() {
        try {
            Runtime runtime = Runtime.getRuntime();
            Process process = runtime.exec("/system/bin/ping -i 5 -c 1 8.8.8.8");
            int exitValue = process.waitFor();
            return exitValue;
        } catch (Exception ex) {
            return -1;
        }
    }

    public static boolean isInternetActiveWithInetAddress() {
        try {

            String host;

            if ( ConfigParams.DEBUG_MODE  )
                host = ConfigParams.DEV_WEBSITE_BASE_URL;
            else
                host = ConfigParams.WEBSITE_BASE_URL;

            InetAddress inetAddress = InetAddress.getByName(host);
            return inetAddress != null && !inetAddress.toString().equals("");
        } catch (Exception ex) {
            return false;
        }
    }

    public static boolean isInternetActive(){
        try{
            /*if (NetworkUtils.isInternetActiveWithPing() == NetworkUtils.STATUS_CONNECTED && NetworkUtils.isInternetActiveWithInetAddress()){
                return true;
            }else{
                return false;
            }*/
            if (NetworkUtils.isInternetActiveWithPing() == NetworkUtils.STATUS_CONNECTED) {
               return true;
            } else {
                if (NetworkUtils.isInternetActiveWithInetAddress()) {
                    return true;
                } else {
                    return false;
                }
            }
            //Log.d("UpdateActionPool" ,"fallo en ping");
            //return false;
        }catch (Exception ex){
            return false;
        }
    }


    public static boolean isOnline(Context context) {

        ConnectivityManager connectivityManager = (ConnectivityManager)
                context.getSystemService(Context.CONNECTIVITY_SERVICE);
        final NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        RunnableFuture<Boolean> futureRun = new FutureTask<Boolean>(new Callable<Boolean>() {
            @Override
            public Boolean call() throws Exception {
                if ((networkInfo.isAvailable()) && (networkInfo.isConnected())) {
                    try {
                        String host;

                        if ( ConfigParams.DEBUG_MODE  )
                            host = ConfigParams.DEV_WEBSITE_BASE_URL;
                        else
                            host = ConfigParams.WEBSITE_BASE_URL;

                        HttpURLConnection urlc = (HttpURLConnection) (new URL(host).openConnection());
                        urlc.setRequestProperty("User-Agent", "Test");
                        urlc.setRequestProperty("Connection", "close");
                        urlc.setConnectTimeout(1200);
                        urlc.connect();
                        return (urlc.getResponseCode() == 200 && NetworkUtils.isInternetActiveWithPing() == NetworkUtils.STATUS_CONNECTED && NetworkUtils.isInternetActiveWithInetAddress());
                    } catch (IOException e) {
                        Log.e(TAG, "Error checking internet connection" + e.getMessage(), e);
                    }
                } else {
                    Log.d(TAG, "No network available!");
                }
                return false;
            }
        });

        new Thread(futureRun).start();

        try {
            return futureRun.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return false;
        }

    }


}
