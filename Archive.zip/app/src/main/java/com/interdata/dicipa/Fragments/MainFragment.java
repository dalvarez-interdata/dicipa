package com.interdata.dicipa.Fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.interdata.dicipa.Activities.MainActivity;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.R;
import com.interdata.dicipa.ConfigParams;


public class MainFragment extends Fragment {

    private Bundle data;
    private SharedPreferences sharedPref;
    public static Handler myHandler ;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        data = getArguments();
        setVariables ();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_main, container , false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            DicipaApp.MyActivity.getWindow().setStatusBarColor(getResources().getColor(R.color.colorAccent,  DicipaApp.MyActivity.getTheme()));
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            DicipaApp.MyActivity.getWindow().setStatusBarColor(getResources().getColor(R.color.colorAccent));
        }
        settingInterface ();
    }

    /*
     * settings variables*/
    /*
     * Sets the variables of the Fragment
     * */
    public void setVariables () {

        DicipaApp.MyFragment = this;
        DicipaApp.MyActivity = getActivity();
        DicipaApp.MyContext = getActivity().getBaseContext();

        getActivity().invalidateOptionsMenu();

        sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);
    }

    /*
     *
     * Sets the visuals interface
     * */
    private void settingInterface () {

        /*
        * Tap on the clinic laboratory image*/
        ImageView iv_clinic_laboratory = getView().findViewById(R.id.iv_clinic_laboratory);
        iv_clinic_laboratory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle data = new Bundle();
                data.putInt("fragment", ConfigParams.CLINIC_LABORATORY_FRAGMENT );
                data.putInt("divisionId", ConfigParams.CLINIC_LABORATORY_FRAGMENT );
                ((MainActivity) DicipaApp.MyActivity).settingFragment(true, data );
            }
        });

        /*
         * Tap on the renal care  image*/
        ImageView iv_renal_care = getView().findViewById(R.id.iv_renal_care);
        iv_renal_care.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle data = new Bundle();
                data.putInt("fragment", ConfigParams.RENAL_CARE_FRAGMENT );
                data.putInt("divisionId", ConfigParams.RENAL_CARE_FRAGMENT );

                ((MainActivity) DicipaApp.MyActivity).settingFragment(true, data );
            }
        });

        /*
         * Tap on the blood bank image*/
        ImageView iv_blood_bank = getView().findViewById(R.id.iv_blood_bank);
        iv_blood_bank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle data = new Bundle();
                data.putInt("fragment", ConfigParams.BLOOD_BANK_FRAGMENT );
                data.putInt("divisionId", ConfigParams.BLOOD_BANK_FRAGMENT );
                ((MainActivity) DicipaApp.MyActivity).settingFragment(true, data );
            }
        });

        /*
         * Tap on the imagenology image*/
        ImageView iv_imagenology = getView().findViewById(R.id.iv_imagenology);
        iv_imagenology.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle data = new Bundle();
                data.putInt("fragment", ConfigParams.IMAGENOLOGY_FRAGMENT );
                data.putInt("divisionId", ConfigParams.IMAGENOLOGY_FRAGMENT );
                ((MainActivity) DicipaApp.MyActivity).settingFragment(true, data );
            }
        });


        ((MainActivity)getActivity()).toolbar.setTitle ( R.string.title_home );
        ((MainActivity)getActivity()).toolbar.setBackgroundColor(DicipaApp.MyContext.getResources().getColor(R.color.white));
        ((MainActivity)getActivity()).toolbar.setTitleTextColor(DicipaApp.MyContext.getResources().getColor(R.color.colorAccent));

        ((MainActivity) DicipaApp.MyActivity).mProgressDialog.dismiss();
        ((MainActivity) DicipaApp.MyActivity).onProgress = false;

    }
}
