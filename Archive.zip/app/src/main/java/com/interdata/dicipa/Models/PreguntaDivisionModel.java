package com.interdata.dicipa.Models;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;

import com.interdata.dicipa.Adapters.DatabaseAdapter;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Persistence.DataBaseHelper;

import java.util.ArrayList;
import java.util.List;

public class PreguntaDivisionModel {

    public static String DB_TABLE_NAME = DataBaseHelper.DB_TABLE_PREFIX + "relacion_preguntas_division";
    public static String DB_TABLE_NAME_ALIAS = "rlpdv";

    public static String DB_INDEX_DIVISION_ID = "id_division";
    public static String DB_INDEX_PREGUNTA_ID = "id_pregunta";
    public static String DB_INDEX_ORDER = "orden";

    private String id;
    private PreguntaModel pregunta;
    private DivisionModel division;
    private int orden;


    //shared preferences var
    private SharedPreferences sharedPref;

    //Database variables
    private SQLiteDatabase model;
    private DatabaseAdapter dbModel;

    public PreguntaDivisionModel ( Context context  ) {

        dbModel = new DatabaseAdapter( context );
        dbModel.open();
        model = dbModel.getmDb();
        sharedPref = DicipaApp.getPreferences();
    }

    public PreguntaDivisionModel() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public PreguntaModel getPregunta() {
        return pregunta;
    }

    public void setPregunta(PreguntaModel pregunta) {
        this.pregunta = pregunta;
    }

    public DivisionModel getDivision() {
        return division;
    }

    public void setDivision(DivisionModel division) {
        this.division = division;
    }

    public int getOrden() {
        return orden;
    }

    public void setOrden(int orden) {
        this.orden = orden;
    }

    /*
     * Gets the list of questions
     *
     * @return List<PreguntaDivisionModel>
     * */
    public List<PreguntaDivisionModel> findAll (Bundle bundle )
    {
        try
        {
            String condition = "";

            String sql = "SELECT * FROM " +  DB_TABLE_NAME + " AS " + DB_TABLE_NAME_ALIAS;
            sql += " INNER JOIN " + DataBaseHelper.DB_TABLE_PREFIX + "preguntas pr ON pr.id_pregunta = " + DB_TABLE_NAME_ALIAS+DB_INDEX_PREGUNTA_ID;
            sql += " INNER JOIN " + DataBaseHelper.DB_TABLE_PREFIX + "divisiones dv ON dv.id_division = " + DB_TABLE_NAME_ALIAS+DB_INDEX_DIVISION_ID;

            if ( bundle.get("division") != null ) {
                condition = " WHERE " + DB_TABLE_NAME_ALIAS + "." + DB_INDEX_DIVISION_ID + " = " + bundle.get("division");
            }

            if ( bundle.get("question") != null ) {
                condition = " WHERE " + DB_TABLE_NAME_ALIAS + "." + DB_INDEX_PREGUNTA_ID + " = " +  bundle.getString("question");
            }

            sql += condition;

            //sort
            sql = sql + " ORDER BY "+DB_TABLE_NAME_ALIAS+"."+DB_INDEX_ORDER+" ASC ";

            Cursor mCur = model.rawQuery(sql, null);

            List<PreguntaDivisionModel> questionsList = new ArrayList<>();

            if (mCur==null)
                return questionsList;

            for (mCur.moveToFirst(); !mCur.isAfterLast(); mCur.moveToNext()) {
                PreguntaDivisionModel question = getQuestionAsObject ( mCur );
                questionsList.add( question );
            }
            mCur.close();

            //find all questions

            return questionsList;
        }
        catch (SQLException mSQLException)
        {
            Log.e(this.getClass().toString(), "findAll >> "+ mSQLException.toString());
            throw mSQLException;
        }
    }

    /*
     * Gets the user object by cursor position
     *
     * @param Cursor cursor
     * @return CategoryDivisionModel
     *
     * */
    public PreguntaDivisionModel getQuestionAsObject ( Cursor cursor ) {

        PreguntaDivisionModel question = new PreguntaDivisionModel ( );

        //BASICS
        int id = cursor.getColumnIndex( "id" );

        int id_pregunta_index = cursor.getColumnIndex( "id_pregunta" );
        int id_tipo_pregunta_index = cursor.getColumnIndex( "id_tipo_pregunta" );
        int pregunta_texto_index = cursor.getColumnIndex( "pregunta" );
        int pregunta_opciones_index = cursor.getColumnIndex( "opciones" );


        int id_division_index = cursor.getColumnIndex( "id_division" );
        int orden_index = cursor.getColumnIndex( "orden" );


        this.division.setId ( cursor.getString ( id_division_index )  );

        PreguntaModel preguntaM = new PreguntaModel();

        preguntaM.setId ( cursor.getString ( id_pregunta_index ) );
        preguntaM.setPregunta ( cursor.getString ( pregunta_texto_index ) );
        preguntaM.setTipoPregunta ( cursor.getInt ( id_tipo_pregunta_index )  );
        preguntaM.setOpciones ( cursor.getString ( pregunta_opciones_index ) );
        question.setPregunta ( preguntaM );

        question.setOrden ( cursor.getInt ( orden_index ) );

        return question;

    }


}
