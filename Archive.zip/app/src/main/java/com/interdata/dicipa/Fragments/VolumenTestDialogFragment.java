package com.interdata.dicipa.Fragments;

import android.app.Dialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Models.CategoryDivisionModel;
import com.interdata.dicipa.Models.DivisionModel;
import com.interdata.dicipa.Models.VolumenTestModel;
import com.interdata.dicipa.R;

import java.util.List;

import io.apptik.widget.MultiSlider;

public class VolumenTestDialogFragment extends DialogFragment {

    private  Bundle data;

    public ProgressDialog mProgressDialog;
    public static Handler myHandler ;



    public static VolumenTestDialogFragment newInstance(String title, Bundle data) {

        VolumenTestDialogFragment frag = new VolumenTestDialogFragment();

        Bundle args = data;
        args.putString("title", title);
        frag.setArguments(args);

        return frag;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        Dialog dialog = super.onCreateDialog(savedInstanceState);

        // request a window without the title
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);

        return dialog;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.volumen_test_dialog_layout, container);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {

        data = getArguments();
        getDialog().setTitle(data.getString("title"));
        getDialog().setCanceledOnTouchOutside(true);
        settingInterface ();

        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void onResume() {

        // Store access variables for window and blank point
        Window window = getDialog().getWindow();
        Point size = new Point();
        // Store dimensions of the screen in `size`
        Display display = window.getWindowManager().getDefaultDisplay();
        display.getSize(size);
        // Set the width of the dialog proportional to 75% of the screen width
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        window.setGravity(Gravity.CENTER);
        // Call super onResume after sizing

        super.onResume();
    }

    private void settingInterface () {

        TextView btn_close = getView().findViewById(R.id.btn_cancel_action);

        TextView test_month_division = getView().findViewById(R.id.test_month_division);
        test_month_division.setText(data.getString("categoryName"));

        btn_close.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                data.putInt("button", 0);
                DicipaApp.data = data;
                dismiss();
            }
        });

        TextView btn_ok = getView().findViewById(R.id.btn_ok_action);
        btn_ok.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                data.putInt("button", 1);
                DicipaApp.data = data;
                dismiss();
            }
        });


        VolumenTestModel model = new VolumenTestModel(DicipaApp.MyContext);

        List<VolumenTestModel> tests = model.findAll(data);

        if ( tests.size() > 0 ) {

            int min = 0;
            int max = 0;
            if (  tests.size() > 0 ) {
                min = tests.get(0).getMin();
                max = tests.get(0).getMax();
            }

            for (int i = 0; i < tests.size(); i++) {
                if (  tests.get(i).getMin() < min )
                    min = tests.get(i).getMin();
                if (  tests.get(i).getMax() > max )
                    max = tests.get(i).getMax();
            }

            final EditText tv_range_slider_min = getView().findViewById(R.id.tv_range_slider_min);
            tv_range_slider_min.setText(String.valueOf(min));

            final EditText tv_range_slider_max = getView().findViewById(R.id.tv_range_slider_max);
            tv_range_slider_max.setText(String.valueOf(max));

            MultiSlider range = getView().findViewById(R.id.range_slider5);
            range.setMin(min);
            range.setMax(max);

            range.getThumb(0).setMin(min);
            range.getThumb(0).setValue(min);
            range.getThumb(1).setValue(max);



            range.setOnThumbValueChangeListener(new MultiSlider.OnThumbValueChangeListener() {
                @Override
                public void onValueChanged(MultiSlider multiSlider,
                                           MultiSlider.Thumb thumb,
                                           int thumbIndex,
                                           int value)
                {
                    if (thumbIndex == 0) {
                        tv_range_slider_min.setText(String.valueOf(value));
                    } else {
                        tv_range_slider_max.setText(String.valueOf(value));
                    }

                }
            });

        } else {
            TextView tv_no_volumen_test_found = getView().findViewById(R.id.tv_no_volumen_test_found);
            tv_no_volumen_test_found.setVisibility(View.VISIBLE);
            LinearLayout ly_test_form = getView().findViewById(R.id.ly_test_form);
            ly_test_form.setVisibility(View.GONE);
            btn_ok.setVisibility(View.GONE);
            btn_close.setText(DicipaApp.MyContext.getResources().getString(R.string.btn_ok));
        }


    }


    private void doAction () {


    }

    @Override
    public void onDismiss(final DialogInterface dialog) {
        super.onDismiss(dialog);

        if (DicipaApp.data != null && DicipaApp.data.get("button") == null )
            DicipaApp.data.putInt("button", 0);

        final Fragment fragment = DicipaApp.MyFragment;
        if (fragment instanceof DialogInterface.OnDismissListener) {
            ((DialogInterface.OnDismissListener) fragment).onDismiss(dialog);
        }
    }



}
