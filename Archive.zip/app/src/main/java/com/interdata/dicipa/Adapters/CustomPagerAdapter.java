package com.interdata.dicipa.Adapters;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.interdata.dicipa.Models.ProductImage;

import com.interdata.dicipa.R;
import com.interdata.dicipa.Vendors.PhotoView.PhotoViewAttacher;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Deivis on 9/22/17.
 */

public class CustomPagerAdapter extends PagerAdapter {

    Context mContext;
    LayoutInflater mLayoutInflater;
    ArrayList<ProductImage> mResources;

    public CustomPagerAdapter(Context context, ArrayList<ProductImage> mResources ) {
        mContext = context;
        mLayoutInflater = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.mResources = mResources;
    }

    @Override
    public int getCount() {
        return mResources.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((LinearLayout) object);
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        View itemView = mLayoutInflater.inflate(R.layout.pager_item, container, false);

            ImageView imageView = itemView.findViewById(R.id.imageView);
            TextView  imageTag =  itemView.findViewById(R.id.imageCaption);

            imageView.setImageDrawable( mResources.get(position).getImageDrawable()  );
            imageTag.setText ( mResources.get(position).getDescription() );
            PhotoViewAttacher photoView = new PhotoViewAttacher ( imageView );

            try{
            photoView.update();
            }catch (IllegalArgumentException e){
                Log.d("Error", e.getMessage());
            }



            container.addView(itemView);

            return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((LinearLayout) object);
    }

}
