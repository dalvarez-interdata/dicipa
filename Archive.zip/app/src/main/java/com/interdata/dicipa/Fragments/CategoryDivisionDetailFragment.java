package com.interdata.dicipa.Fragments;

import android.app.Fragment;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.interdata.dicipa.Activities.MainActivity;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Models.ProductModel;
import com.interdata.dicipa.R;
import com.interdata.dicipa.ConfigParams;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class CategoryDivisionDetailFragment extends Fragment {

    private Bundle data;
    private SharedPreferences sharedPref;
    public static Handler myHandler ;
    int cStatusBar = R.color.colorAccent;
    int cActionBar = R.color.colorAccent;
    List<ProductModel> products;
    private ProductModel model;

    public static CotizationDialogFragment cotizationDialogFragment;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        data = getArguments();

        setVariables ();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_category_division_detail, container , false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        settingInterface ();
    }

    /*
     * settings variables*/
    /*
     * Sets the variables of the Fragment
     * */
    public void setVariables () {

        DicipaApp.MyFragment = this;
        DicipaApp.MyActivity = getActivity();
        DicipaApp.MyContext = getActivity().getBaseContext();

        getActivity().invalidateOptionsMenu();

        sharedPref = getActivity().getPreferences(Context.MODE_PRIVATE);

        model = new ProductModel ( DicipaApp.MyContext );

        getProducts ();

        products = new ArrayList<>();

        /*List<String> p1Images = new ArrayList<>();
        p1Images.add("equipo1.png");
        List<String> p2Images = new ArrayList<>();
        p2Images.add("equipo2.png");
        List<String> p3Images = new ArrayList<>();
        p3Images.add("equipo3.png");
        List<String> p4Images = new ArrayList<>();
        p4Images.add("equipo4.png");

        products.add(new ProductModel("1", "DXC 800", "DCX800SN", "Instrumento automatizado de alto rendimiento para las pruebas de química clínica.", p1Images, null) );
        products.add(new ProductModel("2", "DXC 800 AC", "DCX8034SN", "Instrumento automatizado de alto rendimiento para las pruebas de química clínica.", p2Images, null) );
        products.add(new ProductModel("3", "Biolis 24 | Premium", "BIP8034SN", "Instrumento de mesa, compacto y de fácil manejo, ideal para laboratorios de mediano rendimiento.", p3Images, null) );
        products.add(new ProductModel("3", "H 3000", "HE4000SN", "Equipo semi automatizado de mesa, ideal para laboratorios que comienzan o como respaldo de instrumentos automatizados.", p4Images, null) );*/
    }

    /*
     *
     * Sets the visuals interface
     * */
    private void settingInterface () {

        //setting the interface colors

        if ( data.getString("divisionId").equals("1") ) {
            cStatusBar = R.color.clinic_laboratory_statusbar;
            cActionBar = R.color.clinic_laboratory;
        }
        else if ( data.getString("divisionId").equals("2")  ) {
            cStatusBar = R.color.blood_bank_statusbar;
            cActionBar = R.color.blood_bank;
        }
        else if ( data.getString("divisionId").equals("3")  ) {
            cStatusBar = R.color.imagenology_statusbar;
            cActionBar = R.color.imagenology;
        }
        else if ( data.getString("divisionId").equals("4")  ) {
            cStatusBar = R.color.renal_statusbar;
            cActionBar = R.color.renal;
        }

        //status bar color
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            DicipaApp.MyActivity.getWindow().setStatusBarColor(getResources().getColor(cStatusBar,  DicipaApp.MyActivity.getTheme()));
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            DicipaApp.MyActivity.getWindow().setStatusBarColor(getResources().getColor(cStatusBar) );
        }

        //action bar color
        ((MainActivity)getActivity()).toolbar.setBackgroundColor(DicipaApp.MyContext.getResources().getColor(cActionBar));
        ((MainActivity)getActivity()).toolbar.setTitleTextColor(DicipaApp.MyContext.getResources().getColor(R.color.white));

        //Action bar text
        String title = data.getString("categoryName");
        DicipaApp.MyActivity.setTitle( title );
        ((MainActivity)getActivity()).toolbar.setTitle ( title );

        //layouts
        final LinearLayout tabMenu = getView().findViewById(R.id.ly_tabs_layout_category_detail);
        tabMenu.setBackgroundColor(DicipaApp.MyContext.getResources().getColor(cActionBar));

        //products list
        final TextView tab_products = getView().findViewById(R.id.tv_product_list);
        tab_products.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int count = tabMenu.getChildCount();
                for(int i=0; i<count; i++) {
                    View textView = tabMenu.getChildAt(i);
                    if (textView instanceof TextView) {
                        textView.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.tab_items));
                    }
                }

                ScrollView sv_product_list = getView().findViewById(R.id.sv_product_list);
                sv_product_list.setVisibility(View.VISIBLE);
                LinearLayout ly_product_detail = getView().findViewById(R.id.ly_product_detail);
                ly_product_detail.setVisibility(View.GONE);
                setTabActive (v);
            }
        });

        //product features
        final TextView tab_features = getView().findViewById(R.id.tv_product_features);
        tab_features.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int count = tabMenu.getChildCount();
                for(int i=0; i<count; i++) {
                    View textView = tabMenu.getChildAt(i);
                    if (textView instanceof TextView) {
                        textView.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.tab_items));
                    }
                }
                setTabActive (v);

                ScrollView sv_product_list = getView().findViewById(R.id.sv_product_list);
                sv_product_list.setVisibility(View.GONE);
                LinearLayout ly_product_detail = getView().findViewById(R.id.ly_product_detail);
                ly_product_detail.setVisibility(View.VISIBLE);
            }
        });

        //product requests
        final TextView tv_product_request = getView().findViewById(R.id.tv_product_request);
        tv_product_request.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int count = tabMenu.getChildCount();
                for(int i=0; i<count; i++) {
                    View textView = tabMenu.getChildAt(i);
                    if (textView instanceof TextView) {
                        textView.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.tab_items));
                    }
                }
                setTabActive (v);
            }
        });

        setTabActive ( tab_products );

    }

    private void setAdapterProjects ( List<ProductModel> products ) {

        //get and draw list of products
        RelativeLayout parent = getView().findViewById(R.id.rl_product_list);

        if ( products.size() > 0 ) {
            CardView card = new CardView(DicipaApp.MyContext);

            for (int i = 0; i < products.size(); i++) {
                if (i == 0)
                    card = addProductCard(parent, products.get(i), null);
                else
                    card = addProductCard(parent, products.get(i), card);

                parent.addView(card);

            }
        } else {
            getView().findViewById(R.id.tv_no_result_found).setVisibility(View.VISIBLE);
        }
      //  ((MainActivity) DicipaApp.MyActivity).mProgressDialog.dismiss();
        ((MainActivity) DicipaApp.MyActivity).onProgress = false;


    }

    private void setTabActive ( View view ) {

        final LinearLayout tabMenu = getView().findViewById(R.id.ly_tabs_layout_category_detail);
        int count = tabMenu.getChildCount();
        for(int i=0; i<count; i++) {
            View textView = tabMenu.getChildAt(i);
            if (textView instanceof TextView) {
                textView.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.tab_items));
            }
        }

        if ( data.getString("divisionId").equals("1") ) {
            view.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.tab_active_clinic_laboratory));
        }
        else if ( data.getString("divisionId").equals("2")  ) {
            view.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.tab_active_blood_bank) );
        }
        else if ( data.getString("divisionId").equals("3")  ) {
            view.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.tab_active_imagenology));
        }
        else if ( data.getString("divisionId").equals("4")  ) {
            view.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.tab_active_renal));
        }

    }

    private CardView addProductCard (View parent, final ProductModel product, View above ) {

        View cardview = LayoutInflater.from(DicipaApp.MyContext).inflate(R.layout.layout_product_cardview, ((RelativeLayout) parent), false);

        Random r = new Random();
        int id = Math.abs(r.nextInt());
        cardview.setId(id);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT );
        params.setMargins(46,46,46,46);

        if ( above != null ) {
            params.addRule(RelativeLayout.BELOW, above.getId());
        }
        cardview.setLayoutParams(params);
        ImageView productImage = cardview.findViewById(R.id.iv_product_image_cardview);

        if (product.getImages() != null && product.getImages().size() > 0) {
            try {

                File filesdir = ContextCompat.getExternalFilesDirs(DicipaApp.MyActivity,null)[0];
                String photo = filesdir.getAbsolutePath() + "/" + ConfigParams.PRODUCTS_PATH + "/" + product.getImages().get(0);
                File archivo = new File(photo);
                if (archivo.isFile()) {
                    Drawable drawable = Drawable.createFromPath(photo);
                    productImage.setImageDrawable (drawable);
                } else {
                    try{
                        InputStream ims = DicipaApp.MyActivity.getAssets().open( ConfigParams.PRODUCTS_PATH + "/" + product.getImages().get(0) );
                        Drawable drawable = Drawable.createFromStream(ims, null);
                        productImage.setImageDrawable (drawable);
                    }
                    catch(IOException ex) {

                    }
                }
            } catch (Exception e) {
                //e.printStackTrace();
                Log.d("message", "nooo");
            }
        } else {
            productImage.setImageDrawable (DicipaApp.MyContext.getResources().getDrawable(R.drawable.product_image));
        }

        //content background
        if ( data.getString("divisionId").equals("1") ) {
            cardview.findViewById(R.id.ly_product_content_cardview).setBackgroundColor(DicipaApp.MyContext.getResources().getColor(R.color.clinic_laboratory));
        }
        else if ( data.getString("divisionId").equals("2")  ) {
            cardview.findViewById(R.id.ly_product_content_cardview).setBackgroundColor( DicipaApp.MyContext.getResources().getColor(R.color.blood_bank) );
        }
        else if ( data.getString("divisionId").equals("3")  ) {
            cardview.findViewById(R.id.ly_product_content_cardview).setBackgroundColor( DicipaApp.MyContext.getResources().getColor(R.color.imagenology) );
        }
        else if ( data.getString("divisionId").equals("4")  ) {
            cardview.findViewById(R.id.ly_product_content_cardview).setBackgroundColor( DicipaApp.MyContext.getResources().getColor(R.color.renal));
        }

        //buttons background
        if ( data.getString("divisionId").equals("1") ) {
            cardview.findViewById(R.id.iv_btn_product_add_test_cardview).setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.product_buttons_laboratory));
            cardview.findViewById(R.id.iv_btn_product_more_cardview).setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.product_buttons_laboratory));
            cardview.findViewById(R.id.iv_btn_product_share_cardview).setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.product_buttons_laboratory));
        }
        else if ( data.getString("divisionId").equals("2")  ) {
            cardview.findViewById(R.id.iv_btn_product_add_test_cardview).setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.product_buttons_blood_bank));
            cardview.findViewById(R.id.iv_btn_product_more_cardview).setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.product_buttons_blood_bank));
            cardview.findViewById(R.id.iv_btn_product_share_cardview).setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.product_buttons_blood_bank));
        }
        else if ( data.getString("divisionId").equals("3")  ) {
            cardview.findViewById(R.id.iv_btn_product_add_test_cardview).setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.product_buttons_imagenology));
            cardview.findViewById(R.id.iv_btn_product_more_cardview).setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.product_buttons_imagenology));
            cardview.findViewById(R.id.iv_btn_product_share_cardview).setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.product_buttons_imagenology));
        }
        else if ( data.getString("divisionId").equals("4")  ) {
            cardview.findViewById(R.id.iv_btn_product_add_test_cardview).setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.product_buttons_renal));
            cardview.findViewById(R.id.iv_btn_product_more_cardview).setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.product_buttons_renal));
            cardview.findViewById(R.id.iv_btn_product_share_cardview).setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.product_buttons_renal));
        }

        //product name
        ((TextView) cardview.findViewById(R.id.tv_product_name_cardview)).setText(product.getName());

        //product description
        ((TextView) cardview.findViewById(R.id.tv_product_content_cardview)).setText(product.getTechincalDescription());

        //click over photos
        cardview.findViewById(R.id.iv_product_image_cardview).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity activity = (MainActivity) DicipaApp.MyActivity;
                activity.showImageZoomDialog(new Bundle());
            }
        });

        /*
        * shows product to cotization
        * */
        cardview.findViewById(R.id.iv_btn_product_add_test_cardview).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCotizationProducts ( product );
            }
        });

        /*
         * shows product detail
         * */
        cardview.findViewById(R.id.iv_btn_product_more_cardview).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDetailProduct ( product );
            }
        });

        cardview.findViewById(R.id.tv_product_name_cardview).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDetailProduct ( product );
            }
        });

        cardview.findViewById(R.id.tv_product_content_cardview).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDetailProduct ( product );
            }
        });


        return (CardView) cardview;

    }

    /*
     * get categories */
    public void getProducts () {

       ((MainActivity)getActivity()).onProgress = true;

        myHandler = new Handler(){
            @Override
            public void handleMessage(Message msg) { setAdapterProjects (  products );
            }
        };

        new Thread(new Runnable() {
            public void run() {
                getProductsServices ();
            }
        }).start();

    }

    /*
     * get products from source */
    public void getProductsServices () {

        try {

            Bundle params =  new Bundle ();
            params.putString("category", data.getString("id") );
            products = model.findAll (params);

            Message msg = myHandler.obtainMessage();
            myHandler.sendMessage(msg);

        } catch (Exception e){
            e.printStackTrace();
        }
    }

    /*
    * Show cotization product*/
    /*
     * */
    public void showCotizationProducts ( ProductModel product ) {

        boolean in_shopping_cart = false;
        for (int i = 0; i < DicipaApp.shopping_cart.size(); i++ )
            if ( DicipaApp.shopping_cart.get(i).getId().equals(product.getId()) )
                in_shopping_cart = true;

            if (!in_shopping_cart)
                DicipaApp.shopping_cart.add ( product );

            Log.d("message", String.valueOf(DicipaApp.shopping_cart.size()));

        FragmentManager fm =  ((MainActivity)getActivity()).getSupportFragmentManager();
        Bundle data = new Bundle();
        cotizationDialogFragment = cotizationDialogFragment.newInstance(getResources().getString(R.string.products_to_cotization), data );
        cotizationDialogFragment.show(fm, "fragment_forum_form");

    }

    /*
     * Show the details product*/
    /*
     * */
    public void showDetailProduct ( ProductModel product ) {

        //product features
        final TextView tab_features = getView().findViewById(R.id.tv_product_features);
        setTabActive (tab_features);

        ScrollView sv_product_list = getView().findViewById(R.id.sv_product_list);
        sv_product_list.setVisibility(View.GONE);

        LinearLayout ly_product_detail = getView().findViewById(R.id.ly_product_detail);
        ly_product_detail.setVisibility(View.VISIBLE);

        TextView tv_product_detail_name = getView().findViewById(R.id.tv_product_detail_name);
        tv_product_detail_name.setText(product.getName());

        TextView tv_product_tech_description = getView().findViewById(R.id.tv_product_tech_description);
        tv_product_tech_description.setText(product.getTechincalDescription());

        TextView tv_product_description = getView().findViewById(R.id.tv_product_description);
        tv_product_description.setText(product.getDescription());

        if (product.getImages() != null && product.getImages().size() > 0) {
            try {

                    ImageView productImage = getView().findViewById(R.id.iv_image_sample);
                    File filesdir = ContextCompat.getExternalFilesDirs(DicipaApp.MyActivity,null)[0];
                    String photo = filesdir.getAbsolutePath() + "/" + ConfigParams.PRODUCTS_PATH + "/" + product.getImages().get(0);
                    File archivo = new File(photo);
                    if (archivo.isFile()) {
                        Drawable drawable = Drawable.createFromPath(photo);
                        productImage.setImageDrawable (drawable);
                    } else {
                        try{
                            InputStream ims = DicipaApp.MyActivity.getAssets().open( ConfigParams.PRODUCTS_PATH + "/" + product.getImages().get(0) );
                            Drawable drawable = Drawable.createFromStream(ims, null);
                            productImage.setImageDrawable (drawable);
                        }
                        catch(IOException ex) {

                        }
                    }

            } catch (Exception e) {
                //e.printStackTrace();
                Log.d("message", "nooo");
            }
        } else {
           // ImageView productImage = getView().findViewById(R.id.iv_image_sample);
        }
    }


}
