package com.interdata.dicipa.Webservices;

import android.util.Log;

import com.interdata.dicipa.ConfigParams;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.protocol.HTTP;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.List;


/*
 * 
 * Objeto usado como utilidad para realizar las peticiones HTTP
 */

public class HttpCallRequest {


	public HttpCallRequest() {
	}

	// function get json from url
	// by making HTTP POST or GET method
	public static InputStream makeHttpRequest(String url, String method, List<NameValuePair> params)
			throws UnsupportedEncodingException, ClientProtocolException, java.text.ParseException, IOException {

		InputStream respStr = null;
		// Making HTTP request
		DefaultHttpClient httpClient = new DefaultHttpClient();

		HttpConnectionParams.setConnectionTimeout(httpClient.getParams(), ConfigParams.TIMEOUT_HTTP_REQUEST);
		HttpConnectionParams.setSoTimeout(httpClient.getParams(), ConfigParams.TIMEOUT_HTTP_REQUEST);
		ConnManagerParams.setTimeout(httpClient.getParams(), ConfigParams.TIMEOUT_HTTP_REQUEST);

		// check for request method
		if (method == ConfigParams.HTTP_POST) {

			HttpPost httpPost = new HttpPost(url);
			httpPost.setEntity(new UrlEncodedFormEntity(params, HTTP.UTF_8));

			HttpResponse httpResponse = httpClient.execute(httpPost);

			respStr = httpResponse.getEntity().getContent();

		} else if (method == ConfigParams.HTTP_GET) {

			String paramString = URLEncodedUtils.format(params, "utf-8");
			url += "?" + paramString;

			HttpGet httpGet = new HttpGet(url);
            //Log.d("URL" , "url: " + url);
			HttpResponse httpResponse = httpClient.execute(httpGet);
            respStr = httpResponse.getEntity().getContent();
		}
		return respStr;
	}
}
