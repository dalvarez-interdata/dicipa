package com.interdata.dicipa.Activities;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.interdata.dicipa.Adapters.DatabaseAdapter;
import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Models.UserModel;
import com.interdata.dicipa.R;
import com.interdata.dicipa.Tools.Help;
import com.interdata.dicipa.Tools.NetworkUtils;
import com.interdata.dicipa.Webservices.AsyncURLTask;
import com.interdata.dicipa.Webservices.OperationResult;
import com.interdata.dicipa.Webservices.SyncTaskResultListenerInterface;
import com.interdata.dicipa.Webservices.WebServiceHttpObject;
import com.interdata.dicipa.Webservices.Webservices;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/*
* Sign in activity
* @author Deivis Ricardo
* @date 11/03/2019
* */
public class SignInActivity extends AppCompatActivity {

    private SharedPreferences sharedPref;
    public ProgressDialog mProgressDialog;

    // UI references.
    private AutoCompleteTextView mEmailView;
    private EditText mPasswordView;

    //Database helper
    private static DatabaseAdapter mDbHelper;

    UserModel model;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        settingVariables ();

        settingInterface ();
    }

    /*
    * Init activities variables
    * */
    public void settingVariables () {

        DicipaApp.MyActivity = SignInActivity.this;
        DicipaApp.MyContext = getBaseContext();
        DicipaApp.setPreference();
        sharedPref =  DicipaApp.getPreferences();
        model = new UserModel(DicipaApp.MyContext);

       // List<UserModel> userList = new ArrayList<>();
      //  UserModel modelUser = new UserModel ( DicipaApp.MyContext );
      //  userList = modelUser.findAll(new Bundle () );
     //   Log.d("message", String.valueOf ( userList.size() ) );

    }

    /*
    * Sets the visual interfaces
    * */
    public void settingInterface () {


        // Initialize the progress dialog
        mProgressDialog = new ProgressDialog(SignInActivity.this);
        mProgressDialog.setIndeterminate(true);
        // Progress dialog horizontal style
        mProgressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        // Progress dialog message
        mProgressDialog.setMessage( getBaseContext().getResources().getString(R.string.loading_content_text) );

        if ( sharedPref.getString("session_user_keep_open", null) == null ) {

            setContentView(R.layout.activity_sign_in);

            final View status = findViewById(R.id.v_connection_status);
            status.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.status_offline));
            status.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(SignInActivity.this, getString(R.string.offline_app), Toast.LENGTH_SHORT).show();
                }
            });

          /*  if ( NetworkUtils.isOnline(DicipaApp.MyContext) ) {
                status.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.status_online));
                status.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(SignInActivity.this, getString(R.string.online_app), Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                status.setBackground(DicipaApp.MyContext.getResources().getDrawable(R.drawable.status_offline));
                status.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Toast.makeText(SignInActivity.this, getString(R.string.offline_app), Toast.LENGTH_SHORT).show();
                    }
                });
            }*/

            Button btn_sign_in = findViewById(R.id.btn_sign_in);
            btn_sign_in.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    signIn ();
                }
            });

        } else {

            Intent intent = new Intent(DicipaApp.MyActivity, MainActivity.class);
            startActivity(intent);
            finish();

        }

    }

    /*
    * Do the system sign in*/

    private void signIn () {


        TextView username = findViewById(R.id.edt_username);
        TextView passw = findViewById(R.id.edt_password);
        Switch keep_sesion = findViewById(R.id.swch_keep_sesion);

        if ( username.getText().length() == 0 || passw.getText().length() == 0 ) {
            DicipaApp.showErrorMessage (DicipaApp.MyActivity, getBaseContext().getResources().getString(R.string.validation_error), getBaseContext().getResources().getString(R.string.validation_error_required_fields) );
        } else {

           // if (  NetworkUtils.isOnline(DicipaApp.MyContext) ) {
             hideKeyboard(this);
             attemptToWsSigIn ( username.getText().toString(), passw.getText().toString() );
           // } else {
               //attemptToLocalSignIn ( username.getText().toString(), passw.getText().toString() );
           // }

        }

    }

    /**
     * Attempts to local sign in the account specified by the login form.
     * If there are form errors (invalid email, missing fields, etc.), the
     * errors are presented and no actual login attempt is made.
     */
    private void attemptToLocalSignIn ( String username_or_email, String password ) {
        Bundle params = new Bundle ();
        params.putString("authenticate", username_or_email);
        UserModel user = model.findUser ( params );
        mProgressDialog.setMessage(getBaseContext().getResources().getString(R.string.authenticating_message));
        mProgressDialog.setCanceledOnTouchOutside(false);
        mProgressDialog.show();
        if ( user != null ) {
            if ( user.getPassword().toLowerCase().equals ( Help.sha1( password ) ) ) {
                mProgressDialog.dismiss();
                Switch keep_sesion = findViewById(R.id.swch_keep_sesion);

                SharedPreferences.Editor editor = DicipaApp.getPreferences().edit();
                Date date = new Date();

                editor.putString("session_user", user.getId());
                editor.putString("session_user_person", user.getPerson().getId());
                editor.putString("session_user_name", user.getName() );
                editor.putString("session_user_rol", user.getIdRole() );
                editor.putString("session_user_photo_name", user.getPhoto() );
                editor.putString("session_user_email", user.getEmail() );
                editor.putString("session_user_username", user.getUsername() );

                if ( keep_sesion.isChecked() ) {
                    editor.putString("session_user_keep_open", String.valueOf( date.getTime() ) );
                }

                editor.apply();
                mProgressDialog.dismiss();
                Intent intent =new Intent(DicipaApp.MyActivity,MainActivity.class);
                startActivity(intent);
                finish();

            } else {
                mProgressDialog.dismiss();
                DicipaApp.showErrorMessage (DicipaApp.MyActivity, getBaseContext().getResources().getString(R.string.validation_error), getBaseContext().getResources().getString(R.string.validation_error_wrong_username_or_password) );
            }

        } else {
            mProgressDialog.dismiss();
            DicipaApp.showErrorMessage (DicipaApp.MyActivity, getBaseContext().getResources().getString(R.string.validation_error), getBaseContext().getResources().getString(R.string.validation_error_wrong_username_or_password) );
        }

    }

    /**
     * Attempts to webservie sign in the account specified by the login form.
     * If there are form errors (invalid email, missing fields, etc.), the
     * errors are presented and no actual login attempt is made.
     */
    private void attemptToWsSigIn ( String username_or_email, String password ) {

        //if( NetworkUtils.isOnline(DicipaApp.MyContext) ) {

            try {
                if ( username_or_email.length() == 0 || password.length() == 0 ) {

                    AlertDialog.Builder dialog = new AlertDialog.Builder(SignInActivity.this);
                    dialog.setTitle(R.string.error_message);
                    dialog.setMessage(R.string.required_field);
                    dialog.setPositiveButton(R.string.btn_ok, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        } });
                    dialog.show();

                } else {

                    try {
                        mProgressDialog.show();
                        mProgressDialog.setCanceledOnTouchOutside(false);
                        //btnSignIn.setVisibility(View.GONE);
                        Webservices ws = new Webservices( getBaseContext() );
                        List<WebServiceHttpObject> webServiceHttpObjectList = new ArrayList<>();
                        webServiceHttpObjectList.add(ws.SignIn (username_or_email ,password ) );
                        DicipaApp.asychronous = true;
                        for( WebServiceHttpObject wsObject : webServiceHttpObjectList) {
                            wsObject.setCallback(new SyncTaskResultListenerInterface() {
                                @Override
                                public void onSyncTaskEventCompleted(OperationResult ws_result) {
                                    try {
                                        if ( ws_result.isSuccess() && ws_result.getCode().name().equals( OperationResult.ResultCode.RESULT_SUCCESS.toString() ) ) {

                                            DicipaApp.asychronous = false;
                                            mProgressDialog.setMessage(getBaseContext().getResources().getString(R.string.loading_entering_authenticanting_text));
                                            mProgressDialog.setTitle(getBaseContext().getResources().getString(R.string.loading_authentication_success_text));
                                            final Handler handler = new Handler();
                                            handler.postDelayed(new Runnable() {
                                                @Override
                                                public void run() {
                                                    mProgressDialog.dismiss();
                                                    Intent intent = new Intent(SignInActivity.this, MainActivity.class);
                                                    startActivity(intent);
                                                    finish();
                                                }
                                            }, 1000);


                                        } else {
                                            AlertDialog.Builder dialog = new AlertDialog.Builder(SignInActivity.this);
                                            dialog.setIcon(R.drawable.ic_error);
                                            if (  ws_result.getCode().name().equals( OperationResult.ResultCode.OAUTH2_ERROR_ACCESS_DENIED.toString() ) ) {
                                                dialog.setTitle(R.string.error_message);
                                                dialog.setMessage(R.string.error_wrong_user_or_password);
                                            } else {
                                                dialog.setTitle(R.string.error_message);
                                                dialog.setMessage(R.string.service_error);
                                            }
                                            dialog.setPositiveButton(R.string.btn_ok, new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    dialog.dismiss(); } });
                                            dialog.show();
                                            mProgressDialog.hide();
                                            //btnSignIn.setVisibility(View.VISIBLE);
                                        }
                                    } catch (Exception e) {
                                        mProgressDialog.hide();
                                        //btnSignIn.setVisibility(View.VISIBLE);
                                        new OperationResult(e);
                                    }
                                }
                            });
                            AsyncURLTask wsTask = new AsyncURLTask(wsObject, getBaseContext() );
                            wsTask.execute();
                        }
                    }
                    catch (Exception e){
                        mProgressDialog.hide();
                        //btnSignIn.setVisibility(View.VISIBLE);
                        new OperationResult(e);
                    }

                }
            }
            catch (Exception e){
                mProgressDialog.hide();
                new OperationResult(e);
            }

       /* }
        else {
            DicipaApp.showErrorMessage (DicipaApp.MyActivity, getBaseContext().getResources().getString(R.string.conexion_error), getBaseContext().getResources().getString(R.string.no_internet_access) );
        }*/
    }

    private boolean isEmailValid(String email) {
        //TODO: Replace this with your own logic
        return email.contains("@");
    }

    private boolean isPasswordValid(String password) {
        //TODO: Replace this with your own logic
        return password.length() > 8;
    }

    /*
     * Hide the keyboard
     * */
    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }



}
