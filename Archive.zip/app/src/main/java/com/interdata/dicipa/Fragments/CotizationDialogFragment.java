package com.interdata.dicipa.Fragments;

import android.app.Dialog;
import android.app.Fragment;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.view.Display;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.interdata.dicipa.DicipaApp;
import com.interdata.dicipa.Models.ProductModel;
import com.interdata.dicipa.R;

public class CotizationDialogFragment extends DialogFragment {

    private  Bundle data;

    public ProgressDialog mProgressDialog;

    public static Handler myHandler ;

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        Dialog dialog = super.onCreateDialog(savedInstanceState);

        // request a window without the title
        dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);

        return dialog;
    }

    public static CotizationDialogFragment newInstance(String title, Bundle data) {

        CotizationDialogFragment frag = new CotizationDialogFragment();

        Bundle args = data;
        args.putString("title", title);
        frag.setArguments(args);

        return frag;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_cotization_form, container);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {

        data = getArguments();
        getDialog().setTitle(data.getString("title"));
        getDialog().setCanceledOnTouchOutside(true);
        settingInterface ();

        super.onViewCreated(view, savedInstanceState);

    }

    @Override
    public void onResume() {

        // Store access variables for window and blank point
        Window window = getDialog().getWindow();
        Point size = new Point();
        // Store dimensions of the screen in `size`
        Display display = window.getWindowManager().getDefaultDisplay();
        display.getSize(size);
        // Set the width of the dialog proportional to 75% of the screen width
        window.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
        window.setGravity(Gravity.CENTER);
        // Call super onResume after sizing

        super.onResume();
    }

    private void settingInterface () {

        TextView btn_close = getView().findViewById(R.id.btn_ok_action);
        btn_close.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        final LinearLayout ly_product_list = getView().findViewById(R.id.ly_product_list);

        for ( int i = 0; i < DicipaApp.shopping_cart.size(); i++ ) {
            final View productItem = LayoutInflater.from(DicipaApp.MyContext).inflate(R.layout.layout_cotization_product_item, ly_product_list , false);
            final ProductModel product = DicipaApp.shopping_cart.get(i);
            TextView productName = productItem.findViewById(R.id.tv_product_name);
            productName.setText ( product.getName() );

            final ImageView iv_inc_product = productItem.findViewById(R.id.iv_inc_product);
            final EditText edt_count_product = productItem.findViewById(R.id.edt_count_product);
            final ImageView iv_dec_product = productItem.findViewById(R.id.iv_dec_product);
            final ImageView iv_remove_product = productItem.findViewById(R.id.iv_remove_product);

            //the value in memory
            SharedPreferences sharedPref = DicipaApp.getPreferences();
            if ( !sharedPref.getString(product.getId(), "").equals("") ) {
                edt_count_product.setText( sharedPref.getString(product.getId(), "") );
            }

            iv_inc_product.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    String val = edt_count_product.getText().toString();
                    int valN = Integer.parseInt(val) + 1;
                    edt_count_product.setText(String.valueOf(valN));

                    SharedPreferences.Editor editor = DicipaApp.getPreferences().edit();
                    editor.putString(product.getId(), String.valueOf(valN));
                    editor.apply();

                }
            });

            iv_dec_product.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {

                    String val = edt_count_product.getText().toString();
                    int valN = Integer.parseInt(val) - 1;
                    if ( valN > 0 )
                        edt_count_product.setText(String.valueOf(valN));
                    else {
                        edt_count_product.setText("0");
                        valN = 0;
                    }

                    SharedPreferences.Editor editor = DicipaApp.getPreferences().edit();
                    editor.putString(product.getId(), String.valueOf(valN));
                    editor.apply();


                }
            });

            //remove tap
            iv_remove_product.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    for (int i = 0; i < DicipaApp.shopping_cart.size(); i++ ) {
                        if ( DicipaApp.shopping_cart.get(i).getId().equals(product.getId()) ) {
                            DicipaApp.shopping_cart.remove (DicipaApp.shopping_cart.get(i) );
                            SharedPreferences.Editor editor = DicipaApp.getPreferences().edit();
                            editor.remove(DicipaApp.shopping_cart.get(i).getId());
                            editor.apply();
                            ly_product_list.removeView(productItem);
                        }
                    }

                }
            });

            ly_product_list.addView (productItem );
        }


    }


    private void doAction () {


    }

    @Override
    public void onDismiss(final DialogInterface dialog) {
        super.onDismiss(dialog);
        final Fragment fragment = DicipaApp.MyFragment;
        if (fragment instanceof DialogInterface.OnDismissListener) {
            ((DialogInterface.OnDismissListener) fragment).onDismiss(dialog);
        }
    }


}
